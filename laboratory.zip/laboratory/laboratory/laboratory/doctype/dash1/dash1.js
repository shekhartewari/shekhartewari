// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Labnlyze', {
    refresh: function(frm) {
    
      frm.add_custom_button(__('Get User Email Address'), function(){
        
    }, __("Utilities"));
    
  }
});
  