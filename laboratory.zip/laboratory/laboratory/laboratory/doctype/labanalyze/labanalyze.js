// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt
frappe.require(["/assets/frappe/css/frappe-datatable.min.css",
	"/assets/frappe/js/lib/clusterize.min.js",
	"/assets/frappe/js/lib/Sortable.min.js",
	"/assets/frappe/js/lib/frappe-datatable.min.js",
]);

frappe.ui.form.on('LabAnalyze', {
	// refresh: function(frm) {
	refresh(frm) {

		frm.trigger("prepareFrame");
		frm.disable_save();
		// frm.page.wrapper.find('#myNavbar').hide();
		// frm.page.wrapper.find('.page-head').remove();
		// frm.page.sidebar.hide(); 
		frm.add_custom_button(__("pop"), function () {
			pop_out();
			// getall();
		});

		frm.add_custom_button(__("Get Data"), function () {
			frm.trigger("editFrame");
		}).addClass('blink_5times');
		frm.page.add_inner_button('Sample', () => editFrame('Sample'), 'Module');
		frm.page.add_inner_button('Analysis', () => editFrame('Analysis'), 'Module');
		frm.page.wrapper.find('.layout-main-section-wrapper').append(rtmenuhtml);
		

		frm.add_custom_button(__("Report"), function () {			
			$('#myframe').show().refresh();				
		}).addClass();
		frm.add_custom_button(__("Form"), function () {			
			editFrame();					
		}).addClass();
		frm.add_custom_button(__("change style"), function () {			
			changestyle();			
		}).addClass();
		frm.add_custom_button(__("View"), function () {			
			change_view();			
		}).addClass();
		frm.add_custom_button(__("Rt Menu"), function () {			
			rtmenu();			
		}).addClass();
		frm.add_custom_button(__("Rt menu frame"), function () {			
			rtmenu_iframe();			
		}).addClass();
		frm.add_custom_button(__("F5"), function () {			
			iframe_table_refresh();			
		})
		//create dialog// 
		// var d = new frappe.ui.Dialog({
		// 	'fields': [
		// 		{'fieldname': 'ht', 'fieldtype': 'HTML'},
		// 		{'fieldname': 'today', 'fieldtype': 'Date', 'default': frappe.datetime.nowdate()}
		// 	],
		// 	primary_action: function(){
		// 		d.hide();
		// 		show_alert(d.get_values());
		// 	}
		// });
		// d.fields_dict.ht.$wrapper.html('Hello World');
		// d.show();



		// /create messgae// 
	// 	msgprint("<b>Server Status</b>"
    // + "<hr>"
    // + "<ul>"
    //         + "<li><b>28%</b> Memory</li>"
    //         + "<li><b>12%</b> Processor</li>"
    //         + "<li><b>0.3%</b> Disk</li>"
    // + "</ul>", 'Server Info')


	},
	

});
function wait(ms) {
	var start = new Date().getTime();
	var end = start;
	while (end < start + ms) {
		end = new Date().getTime();
	}
};
// Embed Iframe 
function prepFrame() {
	
	const emptifrm = document.createElement("iframe");
	
	Object.assign(emptifrm, {
		src: "#List/Sample/Report/sample_report2",//builder_std //
		// style:"-webkit-transform:scale(.70);-moz-transform-scale(.70);",
		
		id: "myframe",
		scrolling: "no",
		border: "red",
		allowfullscreen: "true",		
		// height: 850,
		// width: 1450,
		// width: 200,
		overflow:"hidden",
		visibility:"hidden",		
		display:"inline-block",
		frameborder: 0,
		// gesture:"media",		
		
		// sandbox: " allow-scripts allow-same-origin"
	});	

	var ifrmfather = document.getElementsByClassName('form-column ')[0]; // some E DOM instance	//'form-page' //'main-section' // 'layout-main-section' //'full-width'
	// ifrmfather.insertBefore(emptifrm, ifrmfather.children[0]);
	$(emptifrm).insertAfter(ifrmfather.children[0]);


};

function fillFrame(callfrm) {
	callfrm();
	$('#myframe').hide();
	setTimeout(function(){			
		let iframeDocument = document.getElementById("myframe").contentDocument || document.getElementById("myframe").contentWindow.document;
		window.iframedoc=iframeDocument;//making it gl;obal variable
		let nvbar = iframeDocument.querySelector(".navbar");	
		nvbar.parentNode.removeChild(nvbar);	
		
		// page_wrapper.parentNode.removeChild(page_wrapper);
		

		// iframeDocument.body.style.backgroundColor = "#ff0000";		

		// Get HTML head element 
		var head = iframeDocument.getElementsByTagName('HEAD')[0];  

		// Create new link Element 
		var link = iframeDocument.createElement('link'); 

		// set the attributes for link element  
		link.rel = 'stylesheet';  	
		link.type = 'text/css'; 	
		link.href = 'assets/laboratory/css/iframe.css';  //situated at  "assets/laboratory/css"

		// Append link element to HTML head 
		head.appendChild(link);  	
	$('#myframe').show();
	}, 500);
	
	//add right click contect menu


	
};

function editFrame() {
	let iframe1 = document.getElementById('myframe');
	var ndoc = iframe1.contentDocument || iframe1.contentWindow.document;
	let nvbar = ndoc.querySelector(".navbar");
	$('#myframe').show();	
	nvbar.parentNode.removeChild(nvbar);	
};

$(document).ready(function () {
	frappe.run_serially([
		// () => prepFr	ame(),
		() => fillFrame(prepFrame),		
		// () => editFrame(),	
		// () => addcss(),	

	]);
});


// pop out new window

function pop_out() {
	window.open("#List/Sample/Report/sample_report2", "Report", "width=600,height=600,location=no,status=yes,menubar=no,toolbar=no,fullscreen=yes,resizable=no,scrollbars=1");
};

function getall() {
	var elems = document.querySelectorAll( 'body *' );
console.log(elems);

};


// add css file for iframe
function addcss() {
	$("window").on("load", function() {

		changestyle();
	  });

};


// const iframeDocument = document.getElementById("myframe").contentDocument || document.getElementById("myframe").contentWindow.document;
//CSS FOR IFRAME//

function changestyle() {

	const myIframe = document.getElementById("myframe");
	const iframeDocument = document.getElementById("myframe").contentDocument || document.getElementById("myframe").contentWindow.document;

	// iframeDocument.body.style.backgroundColor = "#ff0000";


	let pghd = iframeDocument.getElementsByClassName("page-head flex align-center")[0];
	// pghd.removeChild(pghd.firstElementChild);
	// iframeDocument.getElementsByClassName("page-head flex align-center")[0].style.display="none";
	
	// iframeDocument.getElementsByClassName("col-md-2 layout-side-section")[0].style.display="none"; 
	
	// iframeDocument.getElementsByClassName("container")[0].style.width="1250px";
	// iframeDocument.getElementsByClassName("layout-side-section")[0].style.float="right";
	// iframeDocument.getElementsByClassName("layout-side-section")[0].style.display="none";

	// iframeDocument.getElementsByClassName("layout-side-section")[0].classList.add("col-md-0");

	iframeDocument.getElementsByClassName("layout-side-section")[0].remove();

	iframeDocument.getElementsByClassName("page-form flex")[0].remove();
	iframeDocument.getElementsByClassName("filter-list")[0].remove();
	// iframeDocument.getElementsByClassName("container ")[0].style.marginRight="0px"; //1
	// iframeDocument.getElementsByClassName("container page-body")[0].style.marginRight="25px";
	iframeDocument.getElementsByClassName("layout-main-section-wrapper")[0].classList.remove("col-md-10");
	iframeDocument.getElementsByClassName("layout-main-section-wrapper")[0].classList.add("col-md-12");
	iframeDocument.getElementsByClassName("layout-main-section-wrapper")[0].style.marginBottom="0px";
	// iframeDocument.getElementsByClassName("layout-side-section")[0].classList.remove("col-md-2");
	iframeDocument.getElementsByClassName("btn btn-default btn-more btn-sm margin-left")[0].style.display="none";
	iframeDocument.getElementsByClassName("list-paging-area level")[0].style.justifyContent="left";
	iframeDocument.getElementsByClassName("page-container")[0].style.marginLeft="-80px";

	// iframeDocument.getElementsByClassName("container page-body")[0].style.margin.right=0; 




		   
    // Get HTML head element 
	var head = iframeDocument.getElementsByTagName('HEAD')[0];  

	// Create new link Element 
	var link = iframeDocument.createElement('link'); 

	// set the attributes for link element  
	link.rel = 'stylesheet';  	
	link.type = 'text/css'; 	
	link.href = 'assets/laboratory/css/iframe.css';  //situated at  "assets/laboratory/css"
	
	// Append link element to HTML head 
	head.appendChild(link);  

}

// resize column iframe to 9 col andremaining to 3 col
function change_view() {
	if (document.getElementsByClassName('form-column col-sm-6')[0]) {
		document.getElementsByClassName('form-column col-sm-6')[0].setAttribute("class", "form-column col-sm-1");

	}

	if (document.getElementsByClassName('form-column col-sm-6')[0]) {	
	document.getElementsByClassName('form-column col-sm-6')[0].setAttribute("class", "form-column col-sm-11");
	}	

	else if (document.getElementsByClassName('form-column col-sm-11')[0]){
		document.getElementsByClassName('form-column col-sm-11')[0].setAttribute("class", "form-column col-sm-6");
		if (document.getElementsByClassName('form-column col-sm-1')[0]) {
			document.getElementsByClassName('form-column col-sm-1')[0].setAttribute("class", "form-column col-sm-6");
		}
	}
	// iframeDocument.refresh()
};



let rtmenuhtml = `
<div id="context-menu">
<div class="item">
    <i class="fa fa-list"></i> List
  </div>  	
  <hr>
  <div class="item">
    <i class="fa fa-cut"></i> Cut
  </div>
  <div class="item">
    <i class="fa fa-clone"></i> Copy
  </div>
  <div class="item">
    <i class="fa fa-paste"></i> Paste
  </div>
  <div class="item">
    <i class="fa fa-trash-o"></i> Delete
  </div>
  <hr>
  <div class="item">
    <i class="fa fa-refresh"></i> Reload
  </div>
  <div class="item">
    <i class="fa fa-times"></i> Exit
  </div>
  <div class="item">
    <i class="fa fa-exchange"></i> Refer
  </div>
</div>
`


function rtmenu() {
	window.addEventListener("contextmenu",function(event){
		event.preventDefault();
		var contextElement = document.getElementById("context-menu");
		contextElement.style.top = event.clientY +"px";
		contextElement.style.left = event.clientX +"px";
		contextElement.classList.add("active");
	  });
	  window.addEventListener("click",function(){
		document.getElementById("context-menu").classList.remove("active");
	  });	  

}



function rtmenu_iframe() {
	// console.log(iframedoc)
	var i;
	let select_elm = iframedoc.getElementsByClassName("dt-scrollable")[0];
	let select_list = select_elm.querySelectorAll(".dt-cell"); /*get el having class dt-cell under el having class dt-scrollable[0]*/
	for (i = 0; i < select_list.length; i++) {
		let selected_cell = select_list[i];
		

		selected_cell.addEventListener("contextmenu", function (event) {
			event.preventDefault();
			// console.log(selected_cell.parentNode);

			//get row
			console.log(selected_cell.parentNode.getAttributeNode("data-row-index").value);
			var contextElement = document.getElementById("context-menu");
			contextElement.style.top = event.clientY*.9 + -300+ "px";
			contextElement.style.left = event.clientX*.9 + -20+"px";
			select_elm.style.overflow="hidden";
			contextElement.classList.add("active"); 
			// console.log(selected_cell);
			// ContextMenuService.IsEnabled="False"
			
			
			
			// iframedoc.addEventListener("scroll",contextElement.freeze());
		});

	}
	window.addEventListener("click", function () {
		document.getElementById("context-menu").classList.remove("active");
		// select_elm.style.overflow="auto";
		
	
	});
	iframedoc.addEventListener("click", function () {
		document.getElementById("context-menu").classList.remove("active");
		// select_elm.style.overflow="auto";
	
		
		// console.log(iframedoc.getElementsByClassName("dt-cell--focus")[0]);

	});
	iframedoc.addEventListener("dblclick", function (event) {

		let highlighted_cell_col = iframedoc.getElementsByClassName("dt-cell--highlight")[0];
		// let highlighted_cell_row = highlighted_cell_col.parentNode.parentNode.children[1];
		// console.log(event.target.parentNode.className);
		// console.log(highlighted_cell_row)
		highlighted_cell_col.style.backgroundColor = "red";
		
		// highlighted_cell.style.color='red';
	});


	// console.log(iframedoc.getElementsByClassName("dt-cell--focus")[0]);

};


function iframe_table_refresh() {
	
	let x=iframedoc.getElementsByClassName('page-actions')[0].querySelectorAll('[data-label="Refresh"]');
	$(x).click();
	console.log("clciked");
}




frappe.ui.form.on('LabAnalyze',{
	refresh(frm){
		frm.add_custom_button(__("DT"), function () {
			frm.trigger("datatable");
		}),
		frm.add_custom_button(__("DT1"), function () {
			frm.trigger("datatable");
		}),
		frm.add_custom_button(__("DT2"), function () {
			frm.trigger("datatable");
		})	
		
	},
	datatable: function (frm) {
		frappe.db.get_list('Sample', {
			fields: ['*'],
			filters: {
				'batch': ['>', 0]
			},
			start: 0,
			page_length: 1,
			// as_list:'True'
		})
			.then(r => {
				console.log(r);

				let i;
				let columns = [];							
				let data = [];
				let select_data = [];
				const entriesmap = new Map(Object.entries(r));
				// const keysmap = new Map(Object.keys(r));
				// const valuesmap= new Map(Object.values(r));
				// console.log(keysmap);
				console.log(entriesmap);
				for (let [record, value] of entriesmap) {
					let datalist = [];
					// console.log(record,value);
					// console.log(value);
					const arr2= new Map(Object.entries(value));
					// console.log(arr2);
				for (let [key2,val2] of arr2) {
					let datalist2=[];
					// console.log(key2);
				};
					datalist.push(value.name,value.batch, value.sample_condition, value.nabl, value.date_preserved,value.status);
					data.push(datalist);
					console.log(datalist);
				};
				console.log(data);
				
				columns = [
					{ name: 'Name', id: 'name', editable: true, width: 32, format: value => `${value.fontcolor('red').bold()} ` },
					{ name: 'Batch', editable: false, focusable: true, dropdown: true },//available name,id,editable,resizeable,sortable,focusable,dropdown,width,format
					{ name: 'Sample Condition', editable: false },
					{ name: 'NABL', format: value => `${value.fontcolor('yellow').bold()} ⭐️`, editable: true },
					{ name: 'Date', editable: true },
					{ name: 'Status', format: value => `${value} `, editable: false },

				];

				const options = {
					columns: columns,
					data: data,
					dropdownButton: '▼',
					headerDropdown: [
						{
							label: 'Action 1',
							action: function (column) {
								// custom action
							}
						},
						{
							label: 'Action 2',
							action: function (column) {
								// custom action
							}
						}

					],
					events: {
						onRemoveColumn(column) {datatable.unfreeze()},
						onSwitchColumn(column1, column2) {datatable.unfreeze() },
						onSortColumn(column) { datatable.unfreeze()},
						onCheckRow(row) {
							// datatable.rowmanager.checkAll(0);
							// set other checkbox value to zero first
							$(document).ready(function () {
								$('input[type="checkbox"]').click(function () {
									$('input[type="checkbox"]').not(this).prop('checked', false);

								});
							});

							var selectData = datatable.rowmanager.getCheckedRows().map(x => datatable.options.data[parseInt(x)]);

							console.log(selectData); select_data = selectData; return selectData;
						}

					},
					sortIndicator: {
						asc: '↑',
						desc: '↓',
						none: ''
					},
					freezeMessage: 'Freezed',
					getEditor: null,
					// getEditor(colIndex, rowIndex, value, parent, column, row, data) {
					// 	// colIndex, rowIndex of the cell being edited
					// 	// value: value of cell before edit
					// 	// parent: edit container (use this to append your own custom control)
					// 	// column: the column object of editing cell
					// 	// row: the row of editing cell
					// 	// data: array of all rows

					// 	const $input = document.createElement('input');
					// 	$input.type = 'date';
					// 	parent.appendChild($input);

					// 	return {
					// 		// called when cell is being edited
					// 		initValue(value) {
					// 			$input.focus();
					// 			$input.value = parse(value);
					// 		},
					// 		// called when cell value is set
					// 		setValue(value) {
					// 			$input.value = parse(value);
					// 		},
					// 		// value to show in cell
					// 		getValue() {
					// 			return format($input.value);
					// 		}
					// 	}
					// },
					serialNoColumn: true,
					checkboxColumn: true,
					logs: false,
					layout: 'fluid', // fixed, fluid, ratio
					noDataMessage: 'No Data',
					cellHeight: 25,
					inlineFilters: true,
					treeView: true,
					checkedRowStatus: true,
					dynamicRowHeight: false,
					pasteFromClipboard: true,
					clusterize:true

				};
				const datatable1 = new DataTable('#datatable1', options);
				const datatable2= new DataTable('#datatable2', options);
				const datatable = new DataTable('#datatable', options);//runs frappe-datatable should come after option initialization
				// this runs datatable.net
				// $(document).ready( function () {
				// 	$('#datatable').DataTable();
				// } );	
				// datatable.refresh(data,columns);
				datatable.style.setStyle(`.dt-cell`, { backgroundColor: '#00000', color: '#00FFFF' });
				console.log(select_data);
				// console.log(datatable.options.events.onCheckRow());	
				// console.log(datatable.datamanager.getRow(2));
				// datatable.rowmanager.checkAll(1);
				$(document).ready(function () {
					$('.dt-cell').dblclick(function () {
						console.log('you doubled');
						console.log(this.get);
						console.log(datatable.datamanager.getCell(2, 3).content);
						console.log(datatable.datamanager.getRow());
					});
				});
				console.log(datatable.datamanager.getRows(1, 3));
				console.log(datatable.datamanager.getRowsForView(1, 2));
				console.log(datatable.datamanager.getCell(2, 3).content);
				// datatable.renderHeader();
				// datatable.renderBody();	
				// datatable.render();
				// datatable.getColumn(colIndex);
				// datatable.getColumns();
				// datatable.getRows();
				// datatable.getCell(colIndex,rowIndex);
				// datatable.destroy();
				// datatable.refresh(data,columns);
				// datatable.refreshRow(row,rowIndex);
				// datatable.sortColumn(colIndex, sortOrder);
				// datatable.removeColumn(colIndex);
				// datatable.freeze();
				// datatable.unfreeze();
				// datatable.updateOptions();
				// datatable.fireEvent(eventName, args)
				// datatable.on(event,handler);


			});
		function getSelectedRows(datatable) {
			console.log(datatable.options.data);
		};
	},
});	
