# -*- coding: utf-8 -*-
# Copyright (c) 2020, Shekhar and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe
from frappe import _
from frappe.model.document import Document


class LabAnalyze(Document):
	pass


def execute(filters=None):
    columns, data = [], []
    columns = [
        {
            'fieldname': 'account',
            'label': _('Account'),
            'fieldtype': 'Link',
            'options': 'Account'
        },
        {
            'fieldname': 'currency',
            'label': _('Currency'),
            'fieldtype': 'Link',
            'options': 'Currency'
        },
        {
            'fieldname': 'balance',
            'label': _('Balance'),
            'fieldtype': 'Currency',
            'options': 'currency'
        }
    ]
    data = [
        {
            'account': 'Application of Funds (Assets)',
            'currency': 'INR',
            'balance': '15182212.738'
        },
        {
            'account': 'Current Assets - GTPL',
            'currency': 'INR',
            'balance': '17117932.738'
        }
        
    ]

    return columns, data



@frappe.whitelist()
def pyfunc():
    
    result= frappe.db.get_list('Sample',
        fields=['*'],
        filters={
            'batch': ['>', 1]
        },
        start=0,
        page_length=100,
        # as_list= True
    )
   
    return (result)

# def pyfunc1():
#     # result = frappe.db.get_value('Sample', 'S00002', 'sample_condition')
#     result = frappe.db.get_list('Sample',filters={'batch': ['>', 5]},fields=['batch','sample_condition'],start=0,page_length=1,as_list=False)
#     return (result)