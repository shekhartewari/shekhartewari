// Copyright (c) 2020, Shekhar and contributors

// For license information, please see license.txt

frappe.require(["/assets/frappe/css/frappe-datatable.min.css",
	"/assets/frappe/js/lib/clusterize.min.js",
	"/assets/frappe/js/lib/Sortable.min.js",
	"/assets/frappe/js/lib/frappe-datatable.min.js",
]);
//get CSRF Token
// console.log(frappe.csrf_token);

//run program
frappe.ui.form.on('LabAnalyze', {
	// refresh: function(frm) {
	refresh(frm) {

		frm.trigger("prepareFrame");
		// frm.trigger("datatable");
		frm.trigger("get_row");
		frm.disable_save();
		// frm.add_fetch("batch", "sample_condition", "sample_condition");
		// frm.add_fetch("Sample", "batch", "batch");
		// frm.page.sidebar.html(inserthtml);//insersts html ele into sidebar
		frm.page.wrapper.find('#myNavbar').hide();
		frm.page.wrapper.find('.page-head').show();

		frm.page.wrapper.find('.layout-main-section-wrapper').append(extrhtml);
		frm.add_custom_button(__("Get Data"), function () {
			frm.trigger("datatable");
		}).addClass('blink_5times');
		frm.add_custom_button(__("from_py 4"), function () {
			get_py();
		}).addClass();
		frm.add_custom_button(__("Del record"), function () {
			frm.delrecord();
		}).addClass('blink_infinite');
		frm.add_custom_button(__("datatable2"), function () {
			frm.trigger("datatable5");
		}).addClass();
		frm.add_custom_button(__("Set Route"), function () {
			frappe.set_route('List', 'Sample', 'List');
		}).addClass();
		frm.add_custom_button(__("getSelectedRows"), function () {
			frm.trigger("getSelectedRows");
		}).addClass();
		frm.add_custom_button(__("Get Row"), function () {
			get_row();
		}).addClass();
		frm.page.add_inner_button('New Post', () => new_post(), 'Make1');
		frm.page.sidebar.hide(); // this removes the sidebar
		// frm.page.wrapper.find(".timeline").remove();
		// me.page.wrapper.find(".small").remove();
		// me.page.wrapper.find(".sidebar-menu").remove();
		// me.page.wrapper.find("grey-link dropdown-item").remove();
		frm.add_custom_button(__("Button 18"), function () {
			window.open("#page3");
		}).addClass();
	},

	delrecord: function (frm) {
		frappe.db.delete_doc('Sample', 'TASK00004')
	},

	//DATATABLE
	datatable: function (frm) {
		frappe.db.get_list('Sample', {
			fields: ['*'],
			filters: {
				'batch': ['>', 0]
			},
			start: 0,
			page_length: 4,
			// as_list:'True'
		})
			.then(r => {
				console.log(r);
				// let dataarr0 = [];
				let columns = [];
				let i;
				// const map = new Map(Object.entries(r));
				// for (let [key, value1] of map) {
				// 	dataarr0.push(value1);
				// };
				// console.log(dataarr0);
				// console.log(r);
				let data = [];
				let select_data = [];
				const entriesmap = new Map(Object.entries(r));
				// const keysmap = new Map(Object.keys(r));
				// const valuesmap= new Map(Object.values(r));
				// console.log(keysmap);
				console.log(entriesmap);
				for (let [record, value] of entriesmap) {
					let datalist = [];
					// console.log(record,value);
					// console.log(value);
					const arr2= new Map(Object.entries(value));
					// console.log(arr2);
				for (let [key2,val2] of arr2) {
					let datalist2=[];
					// console.log(key2);
				};
					datalist.push(value.name,value.batch, value.sample_condition, value.nabl, value.date_preserved,value.status);
					data.push(datalist);
					console.log(datalist);
				};
				console.log(data);
				
				columns = [
					{ name: 'Name', id: 'name', editable: true, width: 32, format: value => `${value.fontcolor('red').bold()} ` },
					{ name: 'Batch', editable: false, focusable: true, dropdown: true },//available name,id,editable,resizeable,sortable,focusable,dropdown,width,format
					{ name: 'Sample Condition', editable: false },
					{ name: 'NABL', format: value => `${value.fontcolor('yellow').bold()} ⭐️`, editable: true },
					{ name: 'Date', editable: true },
					{ name: 'Status', format: value => `${value} `, editable: false },


					// { name: 'GitHub Stars', format: value => `${value} ⭐️` }, 
					// { name: 'Age', format: value => `${value} Sample` },
					// { name: 'Project Home', format: value => `${value}` },

				];

				const options = {
					columns: columns,
					data: data,
					dropdownButton: '▼',
					headerDropdown: [
						{
							label: 'Action 1',
							action: function (column) {
								// custom action
							}
						},
						{
							label: 'Action 2',
							action: function (column) {
								// custom action
							}
						}

					],
					events: {
						onRemoveColumn(column) {datatable.unfreeze()},
						onSwitchColumn(column1, column2) {datatable.unfreeze() },
						onSortColumn(column) { datatable.unfreeze()},
						onCheckRow(row) {
							// datatable.rowmanager.checkAll(0);
							// set other checkbox value to zero first
							$(document).ready(function () {
								$('input[type="checkbox"]').click(function () {
									$('input[type="checkbox"]').not(this).prop('checked', false);

								});
							});

							var selectData = datatable.rowmanager.getCheckedRows().map(x => datatable.options.data[parseInt(x)]);

							console.log(selectData); select_data = selectData; return selectData;
						}

					},
					sortIndicator: {
						asc: '↑',
						desc: '↓',
						none: ''
					},
					freezeMessage: 'Freezed',
					getEditor: null,
					// getEditor(colIndex, rowIndex, value, parent, column, row, data) {
					// 	// colIndex, rowIndex of the cell being edited
					// 	// value: value of cell before edit
					// 	// parent: edit container (use this to append your own custom control)
					// 	// column: the column object of editing cell
					// 	// row: the row of editing cell
					// 	// data: array of all rows

					// 	const $input = document.createElement('input');
					// 	$input.type = 'date';
					// 	parent.appendChild($input);

					// 	return {
					// 		// called when cell is being edited
					// 		initValue(value) {
					// 			$input.focus();
					// 			$input.value = parse(value);
					// 		},
					// 		// called when cell value is set
					// 		setValue(value) {
					// 			$input.value = parse(value);
					// 		},
					// 		// value to show in cell
					// 		getValue() {
					// 			return format($input.value);
					// 		}
					// 	}
					// },
					serialNoColumn: true,
					checkboxColumn: true,
					logs: false,
					layout: 'fluid', // fixed, fluid, ratio
					noDataMessage: 'No Data',
					cellHeight: 30,
					inlineFilters: true,
					treeView: false,
					checkedRowStatus: true,
					dynamicRowHeight: false,
					pasteFromClipboard: false

				};
				const datatable = new DataTable('#datatable', options); //runs frappe-datatable should come after option initialization
				// this runs datatable.net
				// $(document).ready( function () {
				// 	$('#datatable').DataTable();
				// } );
				// datatable.refresh(data,columns);
				datatable.style.setStyle(`.dt-cell`, { backgroundColor: '#00000', color: '#00FFFF' });
				console.log(select_data);
				// console.log(datatable.options.events.onCheckRow());	
				// console.log(datatable.datamanager.getRow(2));
				// datatable.rowmanager.checkAll(1);
				$(document).ready(function () {
					$('.dt-cell').dblclick(function () {
						console.log('you doubled');

						console.log(this.get);
						console.log(datatable.datamanager.getCell(2, 3).content);


						console.log(datatable.datamanager.getRow());

					});
				});
				console.log(datatable.datamanager.getRows(1, 3));
				console.log(datatable.datamanager.getRowsForView(1, 2));
				console.log(datatable.datamanager.getCell(2, 3).content);
				// datatable.renderHeader();
				// datatable.renderBody();	
				// datatable.render();
				// datatable.getColumn(colIndex);
				// datatable.getColumns();
				// datatable.getRows();
				// datatable.getCell(colIndex,rowIndex);
				// datatable.destroy();
				// datatable.refresh(data,columns);
				// datatable.refreshRow(row,rowIndex);
				// datatable.sortColumn(colIndex, sortOrder);
				// datatable.removeColumn(colIndex);
				// datatable.freeze();
				// datatable.unfreeze();
				// datatable.updateOptions();
				// datatable.fireEvent(eventName, args)
				// datatable.on(event,handler);


			});
		function getSelectedRows(datatable) {
			console.log(datatable.options.data);
		};
	},
});


function get_row() {
	$(document).ready(function () {
		$('.dt-scrollable').click(function (e) {
			console.log(e.target.className);
			console.log(e.target.getAttribute('data-row-index'));


		});


	});

};

// renove checked rows each time new row is checked

//testing


// $('input.checkbox').on('click', function(e) {
// 	$('input.checkbox').not(this).prop('checked', false);  
// 	console.log('clicked me');
// });

// frappe view
// frappe.provide('frappe.report_view');

//frappe query report
frappe.query_reports["LabAnalyze"] = {
	"filters": [
	]
};


let z = frappe.provide('frappe.views');
console.log(frappe.get_route());

// new function
function get_py() {
	const s = frappe.call({
		method: 'laboratory.laboratory.doctype.labanalyze.labanalyze.pyfunc',
		// args: {
		//     'doctype': 'Item',
		//     'filters': {'name': item_code},
		//     'fieldname': [
		//         'item_name',	
		//         'web_long_description',
		//         'description',
		//         'image',
		//         'thumbnail'
		//     ]
		// },
		callback: function (r) {
			// console.log(r.message);
			return r;
		}
	});
	console.log(s);
	return s;
};


// CUSTOM FORM SCRIPT( can be put under Customisation- Form- LabAnalyze=Client...also)
frappe.ui.form.on('LabAnalyze', {
	refresh(frm) {
		cur_frm.add_fetch("batch", "sample_condition", "sample_condition");
		cur_frm.add_fetch("batch", "nabl", "nabl");
		cur_frm.add_fetch("batch", "container_title", "container_title");
		cur_frm.add_fetch("batch", "container_type", "container_type");
		cur_frm.add_fetch("batch", "analysis_specification", "analysis_specification");
		cur_frm.add_fetch("batch", "analysis_profile", "analysis_profile");
		cur_frm.add_fetch("batch", "sample_procedure", "sample_procedure");
		cur_frm.add_fetch("batch", "date_preserved", "date_preserved");
		cur_frm.add_fetch("batch", "internal_use_only", "internal_use_only");

		// your code here
	}
});
// var html

let inserthtml = `
<ul class="nav nav-tabs nav-stacked" id="myTab" role="tablist" >
<li class="nav-item">
  <a class="nav-link  btn  " id="home-tab" data-toggle="tab"  href="#Sample" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-search " ></span>  Home</a>
</li>
<li class="nav-item">
  <a class="nav-link btn " id="sample-tab" data-toggle="tab" href="#home" role="tab" aria-controls="sample" aria-selected="false" style="text-align:left" >Sample</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="analysis-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Analysis</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="location-tab"  target="_blank" href="#List/Sample/Report" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Location</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="storage-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Storage</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="spcecification-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Specifications</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="profile-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Profile</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="calculation-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false "style="text-align:left" ><span class="glyphicon glyphicon-sound-5-1"></span>Calculation</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="history-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-book"></span>History</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="sop-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-paperclip"></span>SOP</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="instrument-tab" data-toggle="tab" href="#home" role="tab" aria-controls="instrument" aria-selected="false"  style="text-align:left" >  Instrument</a>
</li>
<li class="nav-item">
  <a class="nav-link  btn " id="calibration-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-scale"></span> Calibration</a>
</li>
</ul>
`;

// Embed Iframe 
function prepareFrame() {
	var ifrm = document.createElement("iframe");
	Object.assign(ifrm,{
		src:"http://mylab:8000/desk#List/Sample/Report/sample_report2",
		id: "myframe",
		scrolling: "no",
		allowfullscreen :"true",
		height: 480,
		width: 1600
	})
	// ifrm.setAttribute("src", "http://mylab:8000/desk#List/Sample/Report/sample_report2");
	// ifrm.setAttribute("id", "myframe");
	// ifrm.setAttribute("scrolling",'no');
	// ifrm.setAttribute("allowfullscreen", "true");
	// ifrm.style.width = "1600px";
	// ifrm.style.height = "480px";
	document.body.appendChild(ifrm);
};
prepareFrame();
var iframe=document.getElementById("myframe");




iframe.onload = function () {
	var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
	console.log(iframeDocument.body);
	let extract=iframeDocument.getElementsByClassName('navbar navbar-default navbar-fixed-top')[0].style.display='none';
	iframeDocument.getElementById('navbar-search').style.display='none';

	console.log("working");
	// console.log(extract);
	let alpha=iframeDocument.querySelector('div');
	let beta =alpha.querySelector('#navbar-header navbar-desk');
	console.log(beta);

	
};

// var $iframe = $("#iframeID").contents();
// $iframe.find('selector');



//html add
let extrhtml = '';
let extrhtml1 = '<ul> Inserted </ul>'
	+ '<div id="user"></div>'
	+ '<button id="button1">Get json data</button>'
	+ '<div id="x">x here</div>'
	+ '<button id="button2">Get python fn data</button>';

// COLLPAISBLE

$('layout-side-section').mouseover(function () {
	$('layout-side-section').css('background-color', 'black');
});
//FULLSCREEN

//ADD ID TO CLASS
function addIDtoClass() {
	var x = document.getElementsByClassName("layout-side-section")[0];
	x.id = "mySidebar";
	x.onmouseover = 'testIn()';
	x.onmouseout = 'testOut()';
	var y = document.getElementsByClassName("row layout-main")[0];
	y.id = "myMain";
	var z = document.getElementsByClassName("navbar navbar-default navbar-fixed-top ")[0];
	z.id = "myNavbar";


};
// addIDtoClass();

// var mini = true;

// function toggleSidebar() {
//   if (mini) {
//     console.log("opening sidebar");
//     document.getElementById("mySidebar").style.width = "250px";
//     document.getElementById("main").style.marginLeft = "250px";
//     this.mini = false;
//   } else {
//     console.log("closing sidebar");
//     document.getElementById("mySidebar").style.width = "85px";
//     document.getElementById("main").style.marginLeft = "85px";
//     this.mini = true;
//   }
// };
// document.getElementById("mySidebar").style.width = "250px";
// document.getElementById("myMain").style.marginLeft = "120px";
function testIn() {
	console.log('hovering in sidebar');
};
function testOut() {
	console.log('hovering outside sidebar');
};

// TIMING ANIMATION
// https://css-tricks.com/almanac/properties/a/animation/
// #div5 {animation-timing-function: cubic-bezier(1,0,2,1);}




