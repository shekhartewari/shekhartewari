// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Container Type', {
	// refresh: function(frm) {

	// }
});
