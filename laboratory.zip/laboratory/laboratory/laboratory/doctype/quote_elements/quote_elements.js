// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Quote elements', {
	refresh: function(frm) {
	
	let users = frappe.db.get_values("User",filters={})

	return users


	}
});


