
// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Quote', {
	validate: function(frm,cdt,cdn) {	
		var d = locals[cdt][cdn];			
		var tax_total=0;
		var amount_total=0;	
		var basic_total=0;		
        frm.doc.child_table1.forEach(function(d) {								
			frappe.model.set_value(d.doctype, d.name, 'quote_ref_no', d.parent);	
			
			// d.basic_price_quote =(d.price_quote*d.qty_quote);
			// d.tax_quote=(d.tax_rate_quote*d.basic_price_quote)/100;
			// d.amount_quote=(d.tax_quote)+d.basic_price_quote;
					
			tax_total +=d.tax_quote;	
			amount_total += d.amount_quote;	
			basic_total +=d.basic_price_quote;	
			frm.set_value('amount', amount_total)	
			frm.set_value('tax', tax_total)			
			frm.set_value('basic', basic_total)		
		
		});
	},
	before_save:function(frm) {
		// frm.doc.quote_status="Quote Prepared"
		// console.log(frm.doc.quote_status)
	}	
});

frappe.ui.form.on('Quote elements', {
	qty_quote:function(frm,cdt,cdn) {	
		var d = locals[cdt][cdn];			
		
		// frm.disable_save();	
		frm.add_custom_button(__('Prepare Quote'), function(){
			
			frm.save()
		
			// frm.enable_save();
		
        });			
        //calculate on each change in qty
		frappe.model.set_value(d.doctype, d.name, 'basic_price_quote', (d.price_quote*d.qty_quote));		
		frappe.model.set_value(d.doctype, d.name, 'tax_quote', (d.tax_rate_quote*d.basic_price_quote)/100);			
        frappe.model.set_value(d.doctype, d.name, 'amount_quote', (d.tax_quote)+d.basic_price_quote);	
        frappe.model.set_value(d.doctype, d.name, 'client', frm.doc.client);
		frappe.model.set_value(d.doctype, d.name, 'quote_ref_no', d.parent);
		frappe.model.set_value(d.doctype, d.name, 'test_id', Date.now());

		
		

		// d.basic_price_quote =(d.price_quote*d.qty_quote);
    // d.tax_quote=(d.tax_rate_quote*d.basic_price_quote)/100;
    // d.amount_quote=(d.tax_quote)+d.basic_price_quote;

	

	},
	before_save:function(frm,cdt,cdn) {
		

		
	// 	var d = locals[cdt][cdn];	    		

	// d.price_quote =(d.price_quote*d.qty_quote);
	// d.tax_quote=(d.tax_rate_quote*d.price_quote)/100;
	// d.amount_quote=(d.tax_quote)+d.price_quote;
	


    },
    //calculate on each change in params also
    params_quote:function(frm,cdt,cdn) {
        var d = locals[cdt][cdn];	
       
        frappe.model.set_value(d.doctype, d.name, 'basic_price_quote', (d.price_quote*d.qty_quote));		
		frappe.model.set_value(d.doctype, d.name, 'tax_quote', (d.tax_rate_quote*d.basic_price_quote)/100);			
        frappe.model.set_value(d.doctype, d.name, 'amount_quote', (d.tax_quote)+d.basic_price_quote);	   
    
    
    }
    
});


frappe.ui.form.on('Quote', {
	
	validate: function(frm) {		
		// console.log(frm.doc)
		frm.disable_save()
			{
				if (frm.is_dirty()) {
					frm.enable_save()
					frappe.show_alert('Please save to server',4)
					// frm.refresh_field('quote_ref_no')
				} 
		
			}
		
	}
});

