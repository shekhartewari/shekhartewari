// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt


// set filter..use at the begining of file
frappe.ui.form.on('Test Order', {
	refresh: function(frm) {
		frm.set_query('ref_quote', () => {
			return {
				filters: [
					// ["Quote","quote_status", "in", "frm.doc.quote_status"],
					["Quote","amount", ">", 800]

				]
			}
			
		})
		
	}
});
//END  

// GET PY FUNCTION VALUES IN FORM
// frappe.ui.form.on('Test Order', {
// 	refresh: function(frm) {
// 		frappe.call({
// 			method: 'laboratory.laboratory.doctype.test_order.test_order.pyfunc1',
			// args: {
			// 	'doctype': 'Quote',
			// 	'filters': ["status", frm.doc.status],
			// 	'fieldname': [
			// 		'client','status'	
				   
			// 	]
			// },
			
			// callback: function (r) {
				// console.log(r.message);
				// frm.set_value('filter_quote',r.message)
				// return r;
			// frm.doc.filter_quote="ok";	
			
				
// 			}
			
// 		});
		
// 	}
// });




// frappe.ui.form.on('Test Order', {
// 	refresh: function(frm) {
		
// 		frm.doc.filter_quote="ok";
// 		console.log(frm.doc)
	
		
// 	}
// });

// get_py1(); 	

// GET PY  function OUTSIDE FORM
// function get_py1() {
// 	frappe.call({
// 		method: 'laboratory.laboratory.doctype.test_order.test_order.pyfunc1',
// 		args: {
// 		    'doctype': 'Quote',
// 		    'filters': ["status", "Ordered"],
// 		    'fieldname': [
// 		        'client',	
		       
// 		    ]
// 		},
		
// 		callback: function (r) {
// 			console.log(r.message);
// 			return r;
			
// 		}
// 	});
	
// };
