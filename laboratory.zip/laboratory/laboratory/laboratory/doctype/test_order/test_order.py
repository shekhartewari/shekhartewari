# -*- coding: utf-8 -*-
# Copyright (c) 2020, Shekhar and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe
from frappe.model.document import Document

class TestOrder(Document):
	pass

@frappe.whitelist()
def pyfunc1():
    
    result= frappe.db.get_list('Quote',
    filters={
        # 'quote_status': 'Quote Prepared'
    },
    fields=['name'],
    order_by='amount',
    start=0,
    page_length=20,
    as_list=True
    )

   
    return (result)

