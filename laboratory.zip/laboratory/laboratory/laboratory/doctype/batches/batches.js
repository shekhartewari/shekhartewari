// Copyright (c) 2021, Shekhar and contributors
// For license information, please see license.txt
var counter;
var balance = 0;
frappe.ui.form.on('Batches', {
	onload: function (frm) {
		frm.set_query("aliquots_selected", function () {
			return {
				"filters": {

					"batch": ""

				}
			}
		});

	},
	aliquots_selected: function (frm) {
		

		counter = (cur_frm.doc.aliquots_selected.length - 1)
		balance = cur_frm.doc.tray_size - counter-1;
		if (balance < 0) {
			frappe.throw(__('Tray has only '+cur_frm.doc.tray_size+' slots'))

		

		}
			else 	frappe.show_alert({
				title: __('Notification'),
				indicator: 'green',
				message: __('Selected Aliquot :' + cur_frm.doc.aliquots_selected[counter].aliquots + ' Remaining : ' + balance)
			})

	},
	validate: function (frm) {
		// console.log("selcted")
		let list = [];
		cur_frm.doc.selected_items = ""
		// console.log(cur_frm.doc.derivative)
		// console.log(cur_frm.doc.aliquots_selected)
		if (balance<0){
			frappe.throw(__('Please remove  '+(balance+2)+' slots to proceed' ))
		} else {
			cur_frm.doc.aliquots_selected.forEach(element => {
				list.push(element.aliquots)
	
				cur_frm.doc.selected_items = cur_frm.doc.selected_items + "," + element.aliquots
			});
			
			
		}

	},
	before_submit: function (frm) {
	
		cur_frm.doc.aliquots_selected.forEach(element => {

			frappe.db.set_value('Aliquots', element.aliquots, 'batch', cur_frm.doc.name)
			console.log("Batch set :" + element.aliquots)
		});

	},
	after_cancel: function(frm) {
		cur_frm.doc.selected_items="";

		cur_frm.doc.aliquots_selected.forEach(element => {

			frappe.db.set_value('Aliquots', element.aliquots, 'batch', "")
			frappe.show_alert({
				title: __('Notification'),
				indicator: 'blue',
				message: __('Unblocked Aliquot :' + element.aliquots )
			})
		});
		frappe.throw(' Delete batch '+cur_frm.doc.name+' to re-use Aliquots ')
		

		

	},
	test_method_spec: function (frm) {
		frm.set_query("test_method_spec", function () {
			return {
				"filters": {

					"batch": ""

				}
			}
		});

	},
	refresh: function (frm){
		if(cur_frm.doc.docstatus==1){
			frm.add_custom_button(__('Start Test'), function(){
				frappe.msgprint("starting");
				console.log('starting')
			}, __("Test"));
			frm.add_custom_button(__('Save Test'), function(){
				frappe.msgprint("Saving");
				console.log('saving')
			}, __("Test"));
			frm.add_custom_button(__('Cancel Test'), function(){
				frappe.msgprint("Cancelling");
				console.log('cancelling')
			}, __("Test"));

		} else console.log(cur_frm.doc.docstatus)
		// console.log(cur_frm.doc)
		
	}
});
