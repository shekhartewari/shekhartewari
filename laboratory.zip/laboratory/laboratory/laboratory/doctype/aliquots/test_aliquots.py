# Copyright (c) 2021, Shekhar and Contributors
# See license.txt

# import frappe
import unittest

class TestAliquots(unittest.TestCase):
	pass
