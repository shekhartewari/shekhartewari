// Copyright (c) 2021, Shekhar and contributors
// For license information, please see license.txt
let consumed_volumecc=0;
frappe.ui.form.on('Aliquots', {
	primary_sample: function (frm) {
		frappe.call({
			method: 'frappe.client.get_value',
			args: {
				'doctype': 'Sample',
				'filters': {'name': cur_frm.doc.primary_sample},
				'fieldname': [
					'volume_consumed_cc',
					
				]
			},
			callback: function(r) {
				if (!r.exc) {
					r=r.message
					r=r.volume_consumed_cc
				
					console.log(r)
					frm.set_value('consumed_volumecc',r)
					consumed_volumecc=r
		// frm.set_value('consumed_volumecc',flt(consumed_volumecc))
					frm.set_value('available_volume_cc', flt(cur_frm.doc.original_volumecc) - flt(consumed_volumecc))
					console.log("on primary sample : consumed vol set to "+cur_frm.doc.consumed_volumecc)
					console.log("on primary sample : available vol set to "+cur_frm.doc.available_volume_cc)
					
				}
			}
		});
		// consumed_volumecc=frappe.db.get_value('Sample', cur_frm.doc.primary_sample, 'volume_consumed_cc').then(r=> r.message)
		
	},
	aliquot_volume_cc: function (frm) {
		// frm.set_value('balance_weightgms', cur_frm.doc.original_weight_gms-flt.cur_frm.doc.aliquot_weight_gms)
		// frm.set_value('balance_quantitynos', cur_frm.doc.original_quantitynos-flt.cur_frm.doc.aliquot_quantity_nos)
		
		let volume_consumed_cc;
		
		let docname=cur_frm.doc.primary_sample;
		frappe.call({
			method: "frappe.client.get_list",
			args: {
				doctype: 'Aliquots',
				// filters: ['primary_sample'=cur_frm.doc.name],
				filters: { "primary_sample": ["=", cur_frm.doc.primary_sample] },

				fields: ["aliquot_volume_cc"],
			},
			callback: function (r) {
				r = r.message;
				consumed_volumecc = 0;
				r.forEach((element) => {
					consumed_volumecc = flt(consumed_volumecc) + flt(element.aliquot_volume_cc);
				});			
			return docname,consumed_volumecc
			},
		}).then(r=> {
			cur_frm.doc.consumed_volumecc=consumed_volumecc
			console.log('on aliquot vol.....volume_consumed_cc set to : ' )
			console.log(flt(cur_frm.doc.consumed_volumecc)+flt(cur_frm.doc.aliquot_volume_cc))
			frm.set_value('balance_volumecc', flt(cur_frm.doc.original_volumecc - cur_frm.doc.consumed_volumecc) - flt(cur_frm.doc.aliquot_volume_cc))

		});
	},
	validate: function(frm){
		frappe.db.set_value('Sample', cur_frm.doc.primary_sample, 'volume_consumed_cc', flt(cur_frm.doc.consumed_volumecc)+flt(cur_frm.doc.aliquot_volume_cc))
		console.log( "on validate ...sample volume_consumed_cc set to "+cur_frm.doc.consumed_volumecc)
	},
	before_save: function (frm) {
	
			let balance_volumecc;
	
				
					frappe.db.set_value('Sample', cur_frm.doc.primary_sample, 'balance_volumecc', cur_frm.doc.balance_volumecc)
					console.log('before_save...balance_volumecc set to :' + balance_volumecc)


				},
		

		// })
		

	// },

});

