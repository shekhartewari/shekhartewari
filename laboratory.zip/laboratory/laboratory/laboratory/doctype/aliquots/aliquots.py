# Copyright (c) 2021, Shekhar and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document

class Aliquots(Document):
	pass
	# def validate(self,docname,volume_consumed_cc,value):
		# doc = frappe.get_doc("Sample", docname)
		# doc.volume_consumed_cc=volume_consumed_cc;
		# doc.save()
		# print('validated ran')
		# return

@frappe.whitelist()
def update_vol(doctype,docname,fieldname,value):
		doc = frappe.get_doc(doctype, docname)
	
		# doc.db_set(fieldname, value, update_modified=False)
	
		
		# doc.sampler='kitkat2'
		# doc.reload()
		# doc.save()
		# doc.reload()
		
		return('saved...'+docname+': of-->'+doctype+'..updated'+fieldname+'to'+value)

@frappe.whitelist()
def test_button():
	print('test button clicked')