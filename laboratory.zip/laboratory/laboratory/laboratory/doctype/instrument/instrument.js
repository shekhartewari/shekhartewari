// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Instrument', {
	refresh: function(frm) {
		
    
let rtmenuhtml = `

<ul class="nav nav-tabs" >
  <li class="active"><a href="">Home</a></li>
  <li><a href="">Menu 1</a></li>
  <li><a href="">Menu 2</a></li>
</ul>
<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
    <h3>HOME</h3>
    <p>Some content.</p>
  </div>
  <div id="home" class="tab-pane fade ">
	<h3>Menu 1</h3>
	
    <p>Some content in menu 1.</p>
  </div>
  <div id="home" class="tab-pane fade">
    <h3>Menu 2</h3>
    <p>Some content in menu 2.</p>
  </div>
</div>
`

frm.page.wrapper.find('#custom_navtab').append(rtmenuhtml);
		
  }
 		
});
const elem1=document.querySelector("[data-fieldname='mybutton']");
console.log(elem1);

elem1.id="mybutton";



