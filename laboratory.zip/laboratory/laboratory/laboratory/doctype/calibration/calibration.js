// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt



frappe.ui.form.on('Calibration', {
	refresh: function(frm) {
		frm.doc.next_due_date=frappe.datetime.add_days(frm.doc.date,frm.doc.frequency_days);
		
		
		


		

	},
	submit:function(frm) {


	}
});

frappe.ui.form.on('Calibration', {
	before_save: function (frm) {

		frappe.call({
			"method": "frappe.client.set_value",
			"args": {
				//replace "Target DocType" with the actual target doctype
				"doctype": "Instrument",
				//replace target_doctype_link with a link to the document to be changed
				"name": frm.doc.instrument_asset_number,
				"fieldname": {
					//You can update as many fields as you want.  
					"last_calibration_date": frm.doc.date,
					"last_calibration_vendor": frm.doc.vendor,
					"next_due_date": frm.doc.next_due_date
					// "target_field_4": frm.doc.source_field_4,
					// "status": frm.doc.status  //Make sure that you do not put a comma over the last value
				},
			}
		});
	}
});


// frappe.ui.form.on('Calibration', {
// 	validate: function (frm) {

	
// 	frappe.db.set_value('Instrument', frm.doc.instrument_asset_number, {
// 		status: frm.doc.status,
// 		"last_calibration_date": frm.doc.date,
// 		"last_calibration_vendor": frm.doc.vendor
// 	}).then(r => {
// 		let doc = r.message;
// 		console.log(doc.name);
// 	})
		
// 	}
// });

