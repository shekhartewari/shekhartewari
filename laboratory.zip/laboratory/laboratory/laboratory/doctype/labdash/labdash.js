
frappe.ui.form.on('LabDash', {
	refresh(frm) {
     const datatable = new DataTable('#datatable', {
        columns: ['Name', 'Position', 'Salary'],
        data: [
          ['Faris', 'Software Developer', '$1200'],
		  ['Manas', 'Software Engineer', '$1400'],
		  ['Manas', 'Software Engineer', '$1400'],
        ],
		checkboxColumn: true,
		dropdownButton: '▼',
		inlineFilters: true,
		sortIndicator: {
			asc: '↑',
			desc: '↓',
			none: ''
		},
      });
	}  
});
frappe.require(["/assets/frappe/css/frappe-datatable.css",
   
   "/assets/frappe/js/lib/clusterize.min.js",
   "/assets/frappe/js/lib/Sortable.min.js",
   "/assets/frappe/js/lib/frappe-datatable.js",
   
]);
