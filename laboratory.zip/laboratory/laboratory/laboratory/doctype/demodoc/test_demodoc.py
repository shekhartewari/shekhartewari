# -*- coding: utf-8 -*-
# Copyright (c) 2020, Shekhar and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestDemoDoc(unittest.TestCase):
	pass
