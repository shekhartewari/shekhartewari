
// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

// z

// frappe.ui.form.on('Quote22 elements', {
// 	params_quote2: function(frm,cdt,cdn) {	
// 		var d = locals[cdt][cdn];			
			
// 		frm.add_custom_button(__('Prepare Quote22'), function(){
// 			frm.save()
			
		
// 			// frm.enable_save();
		
//     	});			
// 	// 	frappe.model.set_value(d.doctype, d.name, 'price_quote2', (d.price_quote2*d.qty_quote2));		
// 	// 	frappe.model.set_value(d.doctype, d.name, 'tax_quote2', (d.tax_rate_quote2*d.price_quote2)/100);			
// 	// 	frappe.model.set_value(d.doctype, d.name, 'amount_quote2', (d.tax_quote2)+d.price_quote2);	
// 	// d.price_quote2 =(d.price_quote2*d.qty_quote2);
// 	// d.tax_quote2=(d.tax_rate_quote2*d.price_quote2)/100;
// 	// d.amount_quote2=(d.tax_quote2)+d.price_quote2;

	

// 	},
// 	before_save:function(frm,cdt,cdn) {
// 	// 	var d = locals[cdt][cdn];	    		

// 	// d.price_quote2 =(d.price_quote2*d.qty_quote2);
// 	// d.tax_quote2=(d.tax_rate_quote2*d.price_quote2)/100;
// 	// d.amount_quote2=(d.tax_quote2)+d.price_quote2;
	


// 	}
// });


// frappe.ui.form.on('Quote22', {
// 	validate: function(frm) {		
// 		// console.log(frm.doc)
		
// 			{
// 				if (frm.is_dirty()) {
// 					frappe.show_alert('Please save to server',4)
// 					// frm.refresh_field('quote2_ref_no')
// 				}
		
// 			}
		
// 	}
// });

