// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Sample', {
	refresh: function(frm) {
		// if (!cur_frm.doc.__islocal) {
		// 	$(frm.fields_dict['vue_element'].wrapper)
		// 		.html(frappe.render_template("vuetify", cur_frm.doc.__onload));
		// }

// new Vue({
//     el: '#app',
//     vuetify: new Vuetify(),
//     data () {
//       return {
//         interval: {},
//         value: 0,
//       }
//     },
//     beforeDestroy () {
//       clearInterval(this.interval)
//     },
//     mounted () {
//       this.interval = setInterval(() => {
//         if (this.value === 100) {
//           return (this.value = 0)
//         }
//         this.value += 10
//       }, 1000)
//     },
//   })
		
	}	
});

