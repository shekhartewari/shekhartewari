// Copyright (c) 2020, Shekhar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Sample', {
	refresh: function (frm) {
		var result = 0;
		frappe.call({
			method: "frappe.client.get_list",
			args: {
				doctype: 'Aliquots',
				// filters: ['primary_sample'=cur_frm.doc.name],
				filters:{"primary_sample": ["=", cur_frm.doc.name]},
				limit_page_length: 100,
				fields: ["aliquot_volume_cc"],
			},
			callback: function (r) {
				r = r.message;
				console.log(r)
				result = 0;

				r.forEach((element) => {
					result = result + flt(element.aliquot_volume_cc);

				});
				
				frm.set_value('volume_consumed_cc', result)
				frm.set_value('balance_volumecc',cur_frm.doc.volume-cur_frm.doc.volume_consumed_cc)
				console.log(cur_frm.doc.volume_consumed_cc)
				console.log(cur_frm.doc.balance_volumecc)

			},
		});
	
	}
});

