
frappe.listview_settings['Dummy'] = {
    // add fields to fetch
    add_fields: ['type1'],
    // set default filters

    colwidths: {"name": 1},
    filters: [
        // ['test_status', '=', "Processing"]
    ],
    hide_name_column: true, // hide the last column which shows the `name`
    onload(listview) {
        // triggers once before the list is loaded
        // console.log('loaded')
    },
    refresh: function(listview) {
  
                var method="laboratory.laboratory.lab_api.lab_api.test_button";
        		listview.page.add_menu_item(__("Set as Open"), function() {
        			// listview.call_for_selected_items(method, {"status": "Open"});
                    console.log("open")
        		});
        
        		listview.page.add_menu_item(__("Set as Closed"), function() {
        			listview.call_for_selected_items(method, {"test_status)": "Hold"});
                    console.log(this)
        
                    console.log("working")
        		});
        
                 
                listview.page.add_primary_action_item(__('my function'), function() {
                    frappe.msgprint("Hello World");
                })
        
        	}
  ,
    before_render() {
        // triggers before every render of list records
        // console.log('before_rnder')
    },
    get_indicator(doc) {
        // customize indicator color
        if (doc.name) {
            return [__(doc.name), "green", "public,=,Yes"];
        } else {
            return [__(doc.name), "blue", "public,=,No"];
        }
    },
    // primary_action() {
    //     // overrides primary action 
    // },
    // get_form_link(doc) {
    //     // override the form route for this doc
    // },
    // add a custom button for each row

    button: {
        show(doc) {
            // console.log(doc.tray_size)
            return doc.tray_size;
        },
        get_description(doc) {
            return __('View {0}', [`${doctype}`])
        },
        action(doc) {
            let d = new frappe.ui.Dialog({
                title: 'Analysis',
                fields: [
                    {
                        label: 'First Name',
                        fieldname: 'first_name',
                        fieldtype: 'Data'
                    },
                    {
                        label: 'Type',
                        fieldname: 'type',
                        fieldtype: 'Select',
                        options: ['Aliquot', 'Derivative']
                    },
                    {
                        label: 'Age',
                        fieldname: 'age',
                        fieldtype: 'Int'
                    },
                    {
                        label: 'Selection',
                        fieldname: 'tray_size',
                        options: [5, 10, 2],
                        fieldtype: 'Select'
                    },
                    {
                        label: 'Test Status',
                        fieldname: 'test_status',
                        options: ['Analyse',
                            'Processing',
                            'Hold',
                            'Cancel',
                            'Finished'],
                        fieldtype: 'Select'
                    }

                ],
                primary_action_label: 'Start Test',
                secondary_action_label: 'End Test',
                secondary_action() {

                },

                primary_action(values) {
                    frappe.db.set_value('Batches', doc.name, {
                        'tray_size': values.tray_size,
                        'type': values.type,
                        'test_status': values.test_status
                    });

                    // console.log(values);
                    // console.log(this)
                    refresh_field('doc.test_status');
                    let refresh_btn = $(`[data-original-title="Refresh"]`)[0];
                    refresh_btn.click();
                    cur_list.refresh()
                    //   refresh_btn.trigger('click')
                    //   console.log(refresh_btn)

                    // cur_list.refresh()
                    // doc.refresh()
                    // doc.reload()
                    d.hide();
                    colorise()
                }
            });
            d.show();
            // frappe.set_route('Form', doc.reference_type, doc.reference_name);
        },
        get_label(doc) {
            return doc.test_status;
        },
    },
    // format how a field value is shown
    formatters: {
        title(val) {
            return val.bold();
        },
        test_status(val) {
            return val.bold();
        },
        parameter(val) {
            // return val ? 'Yes' : 'No';
            return val.bold().fontcolor("magenta");
            // return val.classList.add("mystyle");
        }
    }
}

function colorise() {
    const c = document.querySelectorAll(`[title="View Batches"]`)
    c.forEach(element => {
        if (element.innerText == "Processing") {
            element.style.backgroundColor = "yellow"
        } else if (element.innerText == "Hold") {
            element.style.backgroundColor = "cyan"
        } else if (element.innerText == "Cancel") {
            element.style.backgroundColor = "grey"
        } else if (element.innerText == "Finished") {
            element.style.backgroundColor = "limegreen"
        } else element.style.backgroundColor = "orange"
    });
};
colorise()