// Copyright (c) 2016, Shekhar and contributors
// For license information, please see license.txt
/* eslint-disable */
// document.getElementsByClassName('navbar navbar-default navbar-fixed-top')[0].remove();

frappe.query_reports["script_std"] = {
	"filters": [

	]
};

// let scriptstd=frappe.query_reports["script_std"] = {
// 	"filters": [

// 	]
// };
