// Copyright (c) 2016, Shekhar and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Product Group Report"] = {
	"filters": [
	
		// {
		// 	"fieldname": "discipline",
		// 	"fieldtype": "Select",
		// 	"width": 100,
		// 	"reqd": 0,
		// 	"options": ['NABL', 'Self', 'Other'],
		// 	"label": "Discipline"
		// },
		// {
		// 	"fieldname": "product_group",
		// 	"fieldtype": "Data",
		// 	"width": 100,
		// 	"reqd": 0,
		// 	"label": "Product Group"
		// },
		// {
		// 	"fieldname": "product_subgroup",
		// 	"fieldtype": "Data",
		// 	"width": 100,
		// 	"reqd": 0,
		// 	"label": "Product Sub Group"
		// },
		// {
		// 	"fieldname": "code",
		// 	"fieldtype": "Data",
		// 	"width": 100,
		// 	"reqd": 0,
		// 	"label": "Code"
		// },

	]
};
