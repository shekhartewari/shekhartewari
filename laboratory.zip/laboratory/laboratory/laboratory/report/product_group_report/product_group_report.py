# Copyright (c) 2013, Shekhar and contributors
# For license information, please see license.txt

# import frappe

def execute(filters=None):
	return get_columns(), get_data(filters)

def get_data(filters):
	print(f"\n\n\n{filters}\n\n\n")
	return [
		['1.1. BIOLOGICAL DISCIPLINE','1.1.2. Antimicrobial activity Products','Soaps & Detergents','00025']
	]
def get_columns():
	return [
		"Discipline:Data:200",
		"Product Group:Data:300",
		"Product Sub Group:Data:200",
		"Code:Data:60"
	]	