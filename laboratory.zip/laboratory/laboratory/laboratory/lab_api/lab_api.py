from bs4.element import Doctype
import frappe
from frappe import auth
import requests
import json
import os
from bs4 import BeautifulSoup
from dotenv import load_dotenv



load_dotenv() # take environmental variables from .env and load here
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
BASE_URL = os.getenv("BASE_URL")
headers_initial = {
        'Authorization': 'token'+" "+API_KEY+":"+API_SECRET,
   
    }


@frappe.whitelist(allow_guest=True)
def get_report_list(doctype,report_name):

    url = BASE_URL+"/api/method/frappe.desk.form.load.getdoc?doctype="+doctype+"&name="+report_name
    # url = "http://labone:8000/api/method/frappe.desk.form.load.getdoc?doctype=Report&name=sample_report2"
    
    payload = {}
    headers = headers_initial

    response = requests.request("GET", url, headers=headers, data=payload)
    resp_dict = response.json()
    # return resp_dict
    r_list = resp_dict.get("docs")
    # r_json=json.dumps(r_list)

    # r_json=r_json.replace("\\", "")
    p_list = r_list[0].get("json")

    # for key, value in r_list.items():
    # print(key, ":", value)
    # print(value)
    # this is a list of dictionaries
    p_list = p_list.replace("\'", "")
    p_list = p_list.replace("\\", "")
    # p_list=p_list.replace('""',"")
    rt = json.loads(p_list)

    get_dict = rt.get("fields")

#  interchange key and values
    for x in get_dict:
        x[0],x[1] = x[1],x[0]
# add tab suffix on each doctype
        x[0] = ('tab')+x[0]
        # print(x[0]+","+x[1])
# make new element by concatenating and adding {`}
    new_dict = []
    for x in get_dict:
        c=("`"+x[0]+"`"+"."+"`"+x[1]+"`")
        new_dict.append(c)
        # new_dict=json.dumps(get_dict)
        # new_dict=new_dict.replace('""',"")
   
# stringify back via dumps
    # new_dict=json.dumps(new_dict)
    # print(new_dict)
    return (new_dict)


@frappe.whitelist(allow_guest=True)
def get_page(doctype,Doctype):
    url = BASE_URL+"/app/"+doctype+"/view/report/"+Doctype

    headers = headers_initial

    response = requests.request("GET", url, headers=headers)
    resp_dict = response.content
    soup = BeautifulSoup(resp_dict, 'html.parser')

    return soup

# ["`tabSample`.`workflow_state`","`tabSample`.`name`","`tabSample`.`docstatus`"]


@frappe.whitelist()
def lab_api_doc_save(doctype,docname,fieldname,value):
        doc = frappe.get_doc(doctype, docname)
        doc.fieldname=value
        doc.save()
        return('saved...'+docname+': of-->'+doctype+'..updated'+fieldname+'to'+value)

@frappe.whitelist(allow_guest=True)
def login(usr,pwd):
    
    try:
        login_manager = frappe.auth.LoginManager()
        login_manager.authenticate(user=usr,pwd=pwd)
        login_manager.post_login()
    except frappe.exceptions.AutheticationError:
        frappe.clear_messages()
        frappe.local.response["message"]={
            "success_key":0,
            "message": "Authetication Error!"

        }

        return
    api_generate =generate_keys(frappe.session.user)
    user = frappe.get_doc('User',frappe.session.user)


    frappe.response["message"] = {
        "success_key":1,
        "message":"Authentication Success",
        "sid": frappe.session.sid,
        "api_key":user.api_key,
        "api_secret":api_generate,
        "username":user.username,
        "email":user.email
    }

def generate_keys(user):
    user_details = frappe.get_doc('User', user)
    api_secret = frappe.generate_hash(length=15)

    if not user_details.api_key:
        api_key = frappe.generate_hash(length=15)
        user_details.api_key = api_key

    user_details.api_secret = api_secret
    user_details.save()    

    return api_secret


@frappe.whitelist(allow_guest=True)
def lone(doctype,report_name):
    # user = frappe.get_doc('User',frappe.session.user)
    # user_details = frappe.get_doc('User', user)
    return "doctype:"+doctype+ " and report_name :"+report_name

@frappe.whitelist()
def test_button():
    ty='test button clicked'
    print (ty)
    return ty
       