from bs4.element import Doctype
import frappe
import requests
import json
from bs4 import BeautifulSoup


@frappe.whitelist(allow_guest=True)
def test(site):

    url = site+"/api/method/frappe.desk.form.load.getdoc?doctype=Report&name=sample_report2"

    payload = {}
    headers = {
        'Authorization': 'token 54f1ce52593a12a:260fabed6ffb890',
        #  'Authorization': 'token 54f1ce52593a12a:7ef6695aa693140',
        'Cookie': 'sid=Guest; system_user=no; full_name=Guest; user_id=Guest; user_image='
    }

    response = requests.request("GET", url, headers=headers, data=payload)
    resp_dict = response.json()
    r_list = resp_dict.get("docs")
    # r_json=json.dumps(r_list)

    # r_json=r_json.replace("\\", "")
    p_list = r_list[0].get("json")

    # for key, value in r_list.items():
    # print(key, ":", value)
    # print(value)
    # this is a list of dictionaries
    p_list = p_list.replace("\'", "")
    p_list = p_list.replace("\\", "")
    # p_list=p_list.replace('""',"")
    rt = json.loads(p_list)

    get_dict = rt.get("fields")

#  interchange key and values
    for x in get_dict:
        x[0],x[1] = x[1],x[0]
# add tab suffix on each doctype
        x[0] = ('tab')+x[0]
        # print(x[0]+","+x[1])
# make new element by concatenating and adding {`}
    new_dict = []
    for x in get_dict:
        c=("`"+x[0]+"`"+"."+"`"+x[1]+"`")
        new_dict.append(c)
        # new_dict=json.dumps(get_dict)
        # new_dict=new_dict.replace('""',"")
   
# stringify back via dumps
    # new_dict=json.dumps(new_dict)
    # print(new_dict)
    return (new_dict)


@frappe.whitelist(allow_guest=True)
def get_page(site):
    url = site+"/app/sample/view/report/Sample"

    headers = {
        # 'Authorization': 'token 54f1ce52593a12a:260fabed6ffb890',
        # 'Cookie': 'sid=Guest; system_user=no; full_name=Guest; user_id=Guest; user_image='
    }

    response = requests.request("GET", url, headers=headers)
    resp_dict = response.content
    soup = BeautifulSoup(resp_dict, 'html.parser')

    return soup

# ["`tabSample`.`workflow_state`","`tabSample`.`name`","`tabSample`.`docstatus`"]



