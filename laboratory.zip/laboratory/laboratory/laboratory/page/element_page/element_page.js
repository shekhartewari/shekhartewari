frappe.provide('frappe.laboratory'); 


// frappe.require(["/assets/laboratory/node_modules/element-ui/lib/index.js",
// 				"/assets/laboratory/node_modules/element-ui/lib/umd/locale/en.js"])

// import Vue from 'vue'
// import Element from 'element-ui'
// Vue.use(Element)

  
// Vue.component(Select.name, Select)
// Vue.component(Button.name, Button)

frappe.pages['element_page'].on_page_load = function(wrapper) {
	this.page = frappe.ui.make_app_page({
			parent: wrapper,
			title: 'Element Page',
			single_column: true,
	});
	



	wrapper = $(wrapper).find('.layout-main-section');
	wrapper.append(	
		'<ul> element_page.js </ul>' 
		+'<div id="myid">myid</div>'	
	);

	this.page.$export_tool = new frappe.laboratory.ExportTool(this.page);
	console.log('element_page.js loaded')
	// console.log(get_total_price())
};

// let quote_name = function(){
// 	frappe.call({
// 		method: "laboratory.laboratory.page.new_page.new_page.get_total_price", //dotted path to server method
// 		callback: function(r) {
// 			// code snippet
// 			console.log(r.message);
			
// 		}
// 	})
// };
// quote_name();

