# import frappe

# @frappe.whitelist()
# def get_total_price():
#     quote_name = frappe.db.sql("""SELECT name from `tabQuote`""", as_dict=True)[1].name
#     return quote_name
