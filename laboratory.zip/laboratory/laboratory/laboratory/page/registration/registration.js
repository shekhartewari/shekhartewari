// frappe.pages['registration'].on_page_load = function(wrapper) {
// 	var page = frappe.ui.make_app_page({
// 		parent: wrapper,
// 		title: 'Sample Registration',
// 		single_column: true
// 	});
// }


// frappe.require(["/assets/frappe/css/frappe-datatable.min.css",
// 	"/assets/frappe/js/lib/clusterize.min.js",
// 	"/assets/frappe/js/lib/Sortable.min.js",
// 	"/assets/frappe/js/lib/frappe-datatable.min.js",
// ]);

frappe.pages['registration'].on_page_load = function (wrapper) {
	var page = frappe.ui.make_app_page({	
		parent: wrapper,
		title: 'Sample Registration Page',
		single_column: false
	});
	
	//Titles
	page.set_title('My Page') // Set the page title along with the document title. The document title is shown in browser tab.
	page.set_title_sub('Subtitle')//Set the secondary title of the page. It is shown on the right side of the page header.

	//Page Status Indicators and color
	page.set_indicator('Pending', 'blue') //Set the indicator label and color.
	page.clear_indicator() 	//Clear the indicator label and color.

	// **Primary action
	// let $btn = page.set_primary_action('Primary Action', () => create_new(), 'octicon octicon-plus') //Set the primary action button label and handler. The third argument is the icon class which will be shown in mobile view.
	let $btn_home = page.set_primary_action('Primary Action', () => create_new_function(), 'octicon octicon-plus');
	let $btn_home1 = page.set_primary_action('Primary Action2', () => create_new_function1(), 'octicon octicon-plus');
	// page.clear_primary_action // Clear primary action button and handler.

	// **Seconday action
	let $btn2 = page.set_secondary_action('Secodary Action', () => refresh(), 'octicon octicon-sync') //Set the secondary action button label and handler. The third argument is the icon class which will be shown in mobile view.

	// page.clear_secondary_action() // Clear secondary action button and handler.

	// **Menu Items
	page.add_menu_item('Send Email', () => open_email_dialog()) //Add menu items in the Menu dropdown.
	page.add_menu_item('Send Email2', () => open_email_dialog(), true)
	// page.clear_menu()//Remove Menu dropdown with items.

	//  **Action Items
	// page.add_action_item('Delete', () => delete_items()) //Add menu items in the Actions dropdown.
	page.add_action_item('Delete', () => delete_items()) //Add menu items in the Actions dropdown.
	page.add_action_item('Add', () => add_items())
	page.add_action_item('Save', () => delete_items())

	// page.clear_actions_menu() //Remove Actions dropdown with items.

	// **Buttons
	page.add_inner_button('Sample', () => goto_page_function('Sample'));
	page.add_inner_button('Analysis', () => goto_page_function('Analysis'));
	page.add_inner_button('Location', () => goto_page_function('Location'));
	page.add_inner_button('Storage', () => goto_page_function('Storage'));
	page.add_inner_button('Specification', () => goto_page_function('Specification'));
	page.add_inner_button('Profile', () => goto_page_function('Profile'));
	page.add_inner_button('Calculation', () => goto_page_function('Calculation'));
	page.add_inner_button('History', () => goto_page_function('History'));
	page.add_inner_button('SOP', () => goto_page_function('SOP'));
	page.add_inner_button('Instrument', () => goto_page_function('Instrument'));
	page.add_inner_button('Calibration', () => goto_page_function('Calibration'));
	page.add_inner_button('Stock', () => goto_page_function('Stock'));
	page.add_inner_button('DT', () => goto_page_function('loadtable'));

	//add menu with dropdown
	page.add_inner_button('New Post', () => new_post(), 'Make')
	// catch inner toolbar element and give id name
	var inner_toolbar_element = document.querySelectorAll('.btn-xs');
	for (var i = 0; i < inner_toolbar_element.length; i++)
		inner_toolbar_element[i].id = ('menu' + i);
	// show in console
	// for (var i = 0; i < inner_toolbar_element.length; i++)
	// 	console.log(inner_toolbar_element[i].id);

	// page.remove_inner_button('Update Posts') // remove inner button
	// page.remove_inner_button('New Post', 'Make')  // remove dropdown button in a group

	// **Toolbar**
	//page.remove_inner_toolbar() //Remove the inner toolbar.

	// **Fields**
	//Add a form control in the page form toolbar.
	let field = page.add_field({
		label: 'Select Field',
		fieldtype: 'Select',
		fieldname: 'status',
		options: [
			'Open',
			'Closed',
			'Cancelled',
			'Approved'
		],
		"default": "Open",
		change() {
			console.log(field.get_value());
		}

	});
	//let values = page.get_form_values();  //	Get all form values from the page form toolbar in an object.
	//page.clear_fields() // Clear all fields from the page form toolbar.

	let field1 = page.add_field({
		label: 'Link Field',
		fieldtype: 'Link',
		fieldname: 'completed_by',
		options: 'User'
	});
	let field9 = page.add_field({
		fieldtype: "Link",
		fieldname: "sample_number",
		label: "Link to client",
		options: 'Sample'
	});
	let field4 = page.add_field({
		fieldtype: "Int",
		fieldname: "noOfDays",
		label: "Integer Field"
	});
	let field5 = page.add_field({
		fieldtype: "Float",
		fieldname: "length",
		label: "Float Field"
	});
	let field6 = page.add_field({
		fieldtype: "Currency",
		fieldname: "amount",
		label: "Currency Field"
	});
	let field7 = page.add_field({
		fieldtype: "Date",
		fieldname: "StartDate",
		label: "Date Field"
	});
	let field8 = page.add_field({
		fieldtype: "Link",
		fieldname: "sample_number",
		label: "Link to Data Field",
		options: 'Sample'
	});
	let field2 = page.add_field({
		fieldtype: "Data",
		fieldname: "firstName",
		label: "Text Box Field"
	});
	let field10 = page.add_field({
		fieldtype: "Button",
		fieldname: "firstName",
		label: "Text Box Field",
	});

	// let field13 = page.add_field({
	// 	fieldtype: "Text",
	// 	fieldname: "description",
	// 	label: "Text Field"
	// });
	nvbar_wrapper=$(wrapper).find('.page-wrapper');
	nvbar_wrapper.append(`
	<div id="mySidenav" class="sidenav">
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		<a href="#">About22</a>
		<a href="#">Services</a>
		<a href="#">Clients</a>
		<a href="#">Contact</a>
	</div>	
	`)
		
	
	wrapper = $(wrapper).find('.layout-main-section');
	wrapper.append('<ul> Inserted </ul>' +
		'<div id="user"></div>'
		+ '<button id="button1">Get json data</button>'
		+ '<div id="resultant"></div>'
		+ '<button id="button2">Get datatable</button>'
	);

	wrapper.append(`<link rel="stylesheet" href="override1.css">`)

	// to add sidebar

	page.sidebar.html(`
	<ul class="nav nav-tabs nav-stacked" id="myTab" role="tablist" >
	<li class="nav-item">
	  <a class="nav-link  btn btn-warning " id="home-tab" data-toggle="tab"  href="#Sample" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-search " ></span>  Home</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link btn btn-danger" id="sample-tab" data-toggle="tab" href="#home" role="tab" aria-controls="sample" aria-selected="false" style="text-align:left" >Sample</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="analysis-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Analysis</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="location-tab"  target="_blank" href="#List/Sample/Report" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Location</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="storage-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Storage</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="spcecification-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Specifications</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="profile-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" >Profile</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="calculation-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false "style="text-align:left" ><span class="glyphicon glyphicon-sound-5-1"></span>Calculation</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="history-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-book"></span>History</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="sop-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-paperclip"></span>SOP</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary" id="instrument-tab" data-toggle="tab" href="#home" role="tab" aria-controls="instrument" aria-selected="false"  style="text-align:left" >  Instrument</a>
	</li>
	<li class="nav-item">
	  <a class="nav-link  btn btn-primary text-black" id="calibration-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false" style="text-align:left" ><span class="glyphicon glyphicon-scale"></span> Calibration</a>
	</li>
    </ul>
  
  `);

	// to add horizontal tabs 

	wrapper.append(`
		<div id = "append_ext_file"></div>				
	`);
	wrapper.append(`
		<div id = "datatable">datatable</div>				
	`);
	wrapper.append(`
	<div id = "append_1"></div>				
	`);
	wrapper.append(`
	<button onclick="changestuff()" >change stuff</button>				
	`);
	// wrapper.append(`
	// <button onclick="loadtable" >datatable</button>	
	// `)


	$(document).ready(function () {
		// $('#append_ext_file').load("page3.html");
	});
	$(document).ready(function () {
		$('#append_1').load("page1/subpage12",);
	});

	// Embed Iframe 
	const myIframe = document.getElementById("myIframe");

	// adding a button to sidebar
	const bt = document.createElement('button');
	bt.textContent = 'delete';
	let myTab = document.getElementById('myTab');
	myTab.appendChild(bt);
	



	//changing dom properties
	const navitem = document.getElementsByClassName('nav-link');
	for (i = 0; i < navitem.length; ++i) {
		navitem[i].style.background = 'skyblue';
		navitem[i].style.color = 'black';
	}

	document.getElementById("menu0").addEventListener('click', showBtn0);
	document.getElementById("menu1").addEventListener('click', showBtn1);
	document.getElementById('button1').addEventListener('click', loadJson);
	document.getElementById('menu12').addEventListener('click', bigtable);

	function showBtn0() {
		document.getElementById("sample-alltabs").style.display = 'block';
		document.getElementById("analysis-alltabs").style.display = 'none';
	}

	function showBtn1() {
		document.getElementById("analysis-alltabs").style.display = 'block';
		document.getElementById("sample-alltabs").style.display = 'none';
		// document.getElementById("sample-alltabs").childNodes.style.display = 'none';
	}


	// $(function () { $("#menu0").on('click', function () { $("#sample-alltabs").show(); }); });
	// $(function () { $("#menu1").on('click', function () { $("#analysis-alltabs").show(); }); });

	// $(function () { $("#menu0").on('click', function () { $("#sample-alltabs").show(); $("#analysis-alltabs").hide() }); });
	// $(function () { $("#menu1").on('click', function () { $("#analysis-alltabs").show(); }); });

	function loadJson() {
		var xhr = new XMLHttpRequest();
		xhr.open('GET', 'user.json', true);
		xhr.onload = function () {
			if (this.status == 200) {
				var user = JSON.parse(this.responseText);
				var output = '';
				output += '<ul>' +
					'<li> ID: ' + user.id + '</li>' +
					'<li> Name: ' + user.name + '</li>' +
					'<li> Email: ' + user.email + '</li>' +
					'</ul>';
				document.getElementById('user').innerHTML = output;
			}
		}
		xhr.send();
	}

	// using call function on a page
	function loadPython(x) {
		frappe.call({
			method: 'laboratory.laboratory.doctype.labquery.labquery.shekhar',
			args: { x: 10, y: 200 },
			callback: function (r) {
				console.log(r);
				var output = '';
				output += r.message;
				output += x;
				document.getElementById('resultant').innerHTML = output;
			}
		});
	}
	function loadtable() {
		console.log("yup1");
		
		

		
		
			const datatable = new DataTable('#datatable', {
				columns: ['Name', 'Position', 'Salary'],
				data: [
				['Faris', 'Software Developer', '$1200'],
				['Manas', 'Software Engineer', '$1400'],
				['Manas', 'Software Engineer', '$1400'],
				],
				checkboxColumn: true,
				dropdownButton: '▼',
				inlineFilters: true,
				sortIndicator: {
					asc: '↑',
					desc: '↓',
					none: ''
				},
				
			});
		
		console.log("yup4");
		

	};
	

}

// to show a message

// frappe.msgprint('hi shekhar')
// d = new frappe.ui.Dialog({title: 'Hello World'});
// d.show()

// adding color on custom action icons--

function prepFrame() {
	
	const emptifrm = document.createElement("iframe");
	console.log('ran prep');
	
	Object.assign(emptifrm, {
		src: "#List/Sample/Report/sample_report2",//builder_std //
		// style:"-webkit-transform:scale(.70);-moz-transform-scale(.70);",
		
		id: "myframe",
		scrolling: "no",
		border: "red",
		allowfullscreen: "true",		
		// height: 850,
		// width: 1450,
		// width: 200,
		overflow:"hidden",
		visibility:"hidden",		
		display:"inline-block",
		frameborder: 0,
		// gesture:"media",		
		
		// sandbox: " allow-scripts allow-same-origin"
	});	

	// var ifrmfather = document.getElementsByClassName('form-column ')[0]; // some E DOM instance	//'form-page' //'main-section' // 'layout-main-section' //'full-width'
	// ifrmfather.insertBefore(emptifrm, ifrmfather.children[0]);
	// $(emptifrm).insertAfter(ifrmfather.children[0]);
	


};

// function fillFrame(callfrm) {
// 	callfrm();
// 	$('#myframe').hide();
// 	setTimeout(function(){			
// 		let iframeDocument = document.getElementById("myframe").contentDocument || document.getElementById("myframe").contentWindow.document;
// 		window.iframedoc=iframeDocument;//making it gl;obal variable
// 		let nvbar = iframeDocument.querySelector(".navbar");	
// 		nvbar.parentNode.removeChild(nvbar);	
		
// 		// page_wrapper.parentNode.removeChild(page_wrapper);
		

// 		// iframeDocument.body.style.backgroundColor = "#ff0000";		

// 		// Get HTML head element 
// 		var head = iframeDocument.getElementsByTagName('HEAD')[0];  

// 		// Create new link Element 
// 		var link = iframeDocument.createElement('link'); 

// 		// set the attributes for link element  
// 		link.rel = 'stylesheet';  	
// 		link.type = 'text/css'; 	
// 		link.href = 'assets/laboratory/css/iframe.css';  //situated at  "assets/laboratory/css"

// 		// Append link element to HTML head 
// 		head.appendChild(link);  	
// 	$('#myframe').show();
// 	}, 500);
	
// 	//add right click contect menu


	
// };

// function editFrame() {
// 	let iframe1 = document.getElementById('myframe');
// 	var ndoc = iframe1.contentDocument || iframe1.contentWindow.document;
// 	let nvbar = ndoc.querySelector(".navbar");
// 	$('#myframe').show();	
// 	nvbar.parentNode.removeChild(nvbar);	
// 	console.log('ran editframe');
// };

// $(document).ready(function () {
// 	frappe.run_serially([
// 		// () => prepFr	ame(),
// 		() => fillFrame(prepFrame),		
// 		() => editFrame(),	
// 		// () => addcss(),	

// 	]);
// });

function bigtable() {


	frappe.db.get_list('Sample', {
		fields: ['*'],
		filters: {
			'batch': ['>', 50]
		},
		start: 0,
		page_length: 1,
		// as_list:'True'
	})
		.then(r => {
			console.log(r);

			let i;
			let columns = [];							
			let data = [];
			let select_data = [];
			const entriesmap = new Map(Object.entries(r));
			// const keysmap = new Map(Object.keys(r));
			// const valuesmap= new Map(Object.values(r));
			// console.log(keysmap);
			console.log(entriesmap);
			for (let [record, value] of entriesmap) {
				let datalist = [];
				// console.log(record,value);
				// console.log(value);
				const arr2= new Map(Object.entries(value));
				// console.log(arr2);
			for (let [key2,val2] of arr2) {
				let datalist2=[];
				// console.log(key2);
			};
				datalist.push(value.name,value.batch, value.sample_condition, value.nabl, value.date_preserved,value.status);
				data.push(datalist);
				console.log(datalist);
			};
			console.log(data);
			
			columns = [
				{ name: 'Name', id: 'name', editable: true, width: 32, format: value => `${value.fontcolor('red').bold()} ` },
				{ name: 'Batch', editable: false, focusable: true, dropdown: true },//available name,id,editable,resizeable,sortable,focusable,dropdown,width,format
				{ name: 'Sample Condition', editable: false },
				{ name: 'NABL', format: value => `${value.fontcolor('yellow').bold()} ⭐️`, editable: true },
				{ name: 'Date', editable: true },
				{ name: 'Status', format: value => `${value} `, editable: false },

			];

			const options = {
				columns: columns,
				data: data,
				dropdownButton: '▼',
				headerDropdown: [
					{
						label: 'Action 1',
						action: function (column) {
							// custom action
						}
					},
					{
						label: 'Action 2',
						action: function (column) {
							// custom action
						}
					}

				],
				events: {
					onRemoveColumn(column) {datatable.unfreeze()},
					onSwitchColumn(column1, column2) {datatable.unfreeze() },
					onSortColumn(column) { datatable.unfreeze()},
					onCheckRow(row) {
						// datatable.rowmanager.checkAll(0);
						// set other checkbox value to zero first
						$(document).ready(function () {
							$('input[type="checkbox"]').click(function () {
								$('input[type="checkbox"]').not(this).prop('checked', false);

							});
						});

						var selectData = datatable.rowmanager.getCheckedRows().map(x => datatable.options.data[parseInt(x)]);

						console.log(selectData); select_data = selectData; return selectData;
					}

				},
				sortIndicator: {
					asc: '↑',
					desc: '↓',
					none: ''
				},
				freezeMessage: 'Freezed',
				getEditor: null,
				// getEditor(colIndex, rowIndex, value, parent, column, row, data) {
				// 	// colIndex, rowIndex of the cell being edited
				// 	// value: value of cell before edit
				// 	// parent: edit container (use this to append your own custom control)
				// 	// column: the column object of editing cell
				// 	// row: the row of editing cell
				// 	// data: array of all rows

				// 	const $input = document.createElement('input');
				// 	$input.type = 'date';
				// 	parent.appendChild($input);

				// 	return {
				// 		// called when cell is being edited
				// 		initValue(value) {
				// 			$input.focus();
				// 			$input.value = parse(value);
				// 		},
				// 		// called when cell value is set
				// 		setValue(value) {
				// 			$input.value = parse(value);
				// 		},
				// 		// value to show in cell
				// 		getValue() {
				// 			return format($input.value);
				// 		}
				// 	}
				// },
				serialNoColumn: true,
				checkboxColumn: true,
				logs: false,
				layout: 'fluid', // fixed, fluid, ratio
				noDataMessage: 'No Data',
				cellHeight: 25,
				inlineFilters: true,
				treeView: true,
				checkedRowStatus: true,
				dynamicRowHeight: false,
				pasteFromClipboard: true,
				clusterize:true

			};
		
			const datatable = new DataTable('#datatable', options);//runs frappe-datatable should come after option initialization
			// this runs datatable.net
			// $(document).ready( function () {
			// 	$('#datatable').DataTable();
			// } );	
			// datatable.refresh(data,columns);
			datatable.style.setStyle(`.dt-cell`, { backgroundColor: '#00000', color: '#00FFFF' });
			console.log(select_data);
			// console.log(datatable.options.events.onCheckRow());	
			// console.log(datatable.datamanager.getRow(2));
			// datatable.rowmanager.checkAll(1);
			$(document).ready(function () {
				$('.dt-cell').dblclick(function () {
					console.log('you doubled');
					console.log(this.get);
					console.log(datatable.datamanager.getCell(2, 3).content);
					console.log(datatable.datamanager.getRow());
				});
			});
			console.log(datatable.datamanager.getRows(1, 3));
			// console.log(datatable.datamanager.getRowsForView(1, 2));
			console.log(datatable.datamanager.getCell(2, 3).content);
			// datatable.renderHeader();
			// datatable.renderBody();	
			// datatable.render();
			// datatable.getColumn(colIndex);
			// datatable.getColumns();
			// datatable.getRows();
			// datatable.getCell(colIndex,rowIndex);
			// datatable.destroy();
			// datatable.refresh(data,columns);
			// datatable.refreshRow(row,rowIndex);
			// datatable.sortColumn(colIndex, sortOrder);
			// datatable.removeColumn(colIndex);
			// datatable.freeze();
			// datatable.unfreeze();
			// datatable.updateOptions();
			// datatable.fireEvent(eventName, args)
			// datatable.on(event,handler);


		});
	function getSelectedRows(datatable) {
		console.log(datatable.options.data);
	};
}

