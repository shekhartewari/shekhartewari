frappe.pages['labone-mainframe'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Labone Mainframe',
		single_column: true
	});

wrapper = $(wrapper).find('.layout-main-section');
wrapper.append( '<div id="idvuetify">idvuetify</div>' );

idvuetify_wrapper = $(wrapper).find('#idvuetify');
idvuetify_wrapper.html(frappe.render_template("vuetify"),{id:'3'});
new Vue({
    el: '#app3',
    vuetify: new Vuetify(),
    data () {
      return {
        interval: {},
        value: 0,
      }
    },
    beforeDestroy () {
      clearInterval(this.interval)
    },
    mounted () {
      this.interval = setInterval(() => {
        if (this.value === 100) {
          return (this.value = 0)
        }
        this.value += 10
      }, 1000)
    },
  })
}
