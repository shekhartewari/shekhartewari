frappe.provide('frappe.laboratory');

frappe.pages['mylabpage'].on_page_load = function (wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'mylabpage',
		single_column: true
	});
	wrapper = $(wrapper).find('.layout-main-section');
	wrapper.append(`
		<div id = "body1"></div>				
	`);
	// $('#body1').load('http://localhost:8000/app/sample/view/report#');
	// $(frappe.render(laboratory.laboratory.labone.body,this)).appendTo(this.page.main)
	console.log("mylabppage")

	 computed1 =
	 
		frappe.call({
			method: "frappe.client.get_list",
			async: true,
			args: {
				doctype: 'Sample',
				filters: [],
				
			},
			callback: function (r) {
				if (!r.exc) {
				result = r.message;

				console.log(result);
				return result
			}
		}
		})
	
		



		// METHOD 2

		// clback= 
		// 	frappe.db.get_list('Sample', {
		// 	fields: ['*'],
		// 	filters: {
		// 		'batch': ['>', 50]
		// 	},
		// 	start: 0,
		// 	page_length: 1,
		// 	as_list:'True'
		// }).then(r => {
		// 	console.log(r)
		// 	result=r.message
		// 	console.log(result)
		// 	return result
		// });
		
		// method 4

		  
		  



		

			document.getElementById('body1').innerText =computed1;

			// METHOD3

			function bigtable() {


				frappe.db.get_list('Sample', {
					fields: ['*'],
					filters: {
						'batch': ['>', 50]
					},
					start: 0,
					page_length: 1,
					// as_list:'True'
				})
					.then(r => {
						console.log(r);
			
						let i;
						let columns = [];							
						let data = [];
						let select_data = [];
						const entriesmap = new Map(Object.entries(r));
						// const keysmap = new Map(Object.keys(r));
						// const valuesmap= new Map(Object.values(r));
						// console.log(keysmap);
						console.log(entriesmap);
						for (let [record, value] of entriesmap) {
							let datalist = [];
							// console.log(record,value);
							// console.log(value);
							const arr2= new Map(Object.entries(value));
							// console.log(arr2);
						for (let [key2,val2] of arr2) {
							let datalist2=[];
							// console.log(key2);
						};
							datalist.push(value.name,value.batch, value.sample_condition, value.nabl, value.date_preserved,value.status);
							data.push(datalist);
							console.log(datalist);
						};
						console.log(data);
						
						columns = [
							{ name: 'Name', id: 'name', editable: true, width: 32, format: value => `${value.fontcolor('red').bold()} ` },
							{ name: 'Batch', editable: false, focusable: true, dropdown: true },//available name,id,editable,resizeable,sortable,focusable,dropdown,width,format
							{ name: 'Sample Condition', editable: false },
							{ name: 'NABL', format: value => `${value.fontcolor('yellow').bold()} ⭐️`, editable: true },
							{ name: 'Date', editable: true },
							{ name: 'Status', format: value => `${value} `, editable: false },
			
						];
			
					
			
			
			
					});
		
			}
			
			






		
};
//   const fun2=function(){
// 	  return 5
// 	console.log("fin2")
//   };

//   fun2()






	  

// frappe-bench/apps/laboratory/laboratory/laboratory/page/labone/labone.js