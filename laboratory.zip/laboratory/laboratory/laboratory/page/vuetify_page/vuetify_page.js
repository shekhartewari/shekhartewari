// frappe.require(["/assets/laboratory/node_modules/vuetify/lib/index.js",
				// "/assets/laboratory/node_modules/vuetify/lib/locale/en.js"])
// frappe.require(frappe.laboratory)

frappe.pages['vuetify-page'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Vuetify Page',
		single_column: true
	});




	// $('.html,body').css("background-color","pink")
	// To disable scroll for entire body
	// $('html, body').css({
	// 	overflow: 'auto',
	// 	height: 'auto'
	// });
	$('.navbar').css("display","none")
	$('.page-head').css("display","none")
	// $('.page-body').css("width","100%")
	// $('.page-body').css("padding","0")
	// $('.page-head').css("background-color","yellow")
	// $('.page-container').css("background-color","aquamarine")
	

	// $('.main-section').css("background","teal")

	// wrapper = $(wrapper).find('.layout-main-section');
	// wrapper.css("background-color","red")
	// wrapper.append(	
	// 	'<ul> vuetify_page.js </ul>' 
		// +'<div id = "idvuetify"></div>'
	// 	+'<div id = "idvtfy"></div>'
	
	
	// );

	// this.page.$export_tool = new frappe.laboratory.VeutifyTool(this.page);
	newvue = new frappe.laboratory.VeutifyTool(this.page);
	console.log('vuetify.js and Vuetify Tool loaded');
	// console.log(newvue)

	// kill vue instance on route change thru plain js
	window.addEventListener('popstate', function (event) {
		// Log the state data to the console
		// newvue = null;
		console.log("route changed ");
	
		// $('.navbar').css("display","flex")
		// $('.page-head').css("display","flex")
		// 
		
	});
	// enable scroll lock
	window.addEventListener("scroll",function(){
		window.scrollTo(0,0);
	});


	
}

