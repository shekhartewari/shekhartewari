import frappe


@frappe.whitelist()
def shekhar():
    # z = int(x)+int(y)
    return ("hehe")


@frappe.whitelist()
def get_meta_wl(doctype):

    y = frappe.get_meta(doctype)
    z = y.fields
    b = [x for x in z]
    return b
