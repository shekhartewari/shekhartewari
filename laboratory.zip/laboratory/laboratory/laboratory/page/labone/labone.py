import frappe

@frappe.whitelist()
def get_total_price():
    total = frappe.db.sql("""SELECT sample_no from `tabSample`""", as_dict=True)[2].sample_no
    return total



