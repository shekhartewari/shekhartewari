

frappe.pages['labone'].on_page_load = function(wrapper) {
	new MyPage(wrapper);

}

// PAGE CONTENT	
MyPage = Class.extend({
	init: function(wrapper){
		this.page = frappe.ui.make_app_page({
			parent: wrapper,
			title: 'LabOne Home',
			single_column: true
		});	
			// make page
		this.make();
	},



	//make page
	make: function(){
		//grab the class
		let me = $(this);

		// body content
		let total = function(){
			frappe.call({
				method: "laboratory.laboratory.page.labone.labone.get_total_price", //dotted path to server method
				callback: function(r) {
					// code snippet
					console.log(r);
					$("#total-price")[0].innerText = r.message;
				}
			})
		}
		// insert table

		let page_table = function(){
			// let element = document.querySelector('#datatable');

			let datatabel = new frappe.DataTable('#datatable', {
				columns: ['Framework', 'Built By', 'GitHub Stars', 'License', 'Contributors', 'Age','Project Home', 'Project Link'],
				data: [
					['React', 'Facebook', 149017, 'MIT', 1385, '7 Years', 'https://reactjs.org', 'https://github.com/facebook/react'],
					['Angular', 'Google', 61263, 'MIT', 1119, '5 Years', 'https://angular.io', 'https://github.com/angular/angular'],
					['Vue', 'Evan You', 164408, 'MIT', 293, '4 Years', 'https://vuejs.org', 'https://github.com/vuejs/vue'],
					['Svelte', 'Rich Harris', 33865, 'MIT', 298, '3 Years', 'https://svelte.dev', 'https://github.com/sveltejs/svelte/'],
					['Stencil', 'Ionic Team', 7749, 'MIT', 132, '3 Years', 'https://stenciljs.com', 'https://github.com/ionic-team/stencil'],
				],
				dropdownButton: '▼',
				headerDropdown: [
					{
						label: 'Custom Action',
						action: function (column) {
							// custom action
						}
					}
				],
				events: {
					onRemoveColumn(column) {},
					onSwitchColumn(column1, column2) {},
					onSortColumn(column) {},
					onCheckRow(row) {}
				},
				sortIndicator: {
					asc: '↑',
					desc: '↓',
					none: ''
				},
				freezeMessage: '',
				getEditor: null,
				serialNoColumn: true,
				checkboxColumn: false,
				logs: false,
				layout: 'fluid', // fixed, fluid, ratio
				noDataMessage: 'No Data',
				// cellHeight: null,
				inlineFilters: false,
				treeView: false,
				checkedRowStatus: true,
				dynamicRowHeight: false,
				pasteFromClipboard: false
			});

		}

	

		// insert chart
		let page_chart = function(){

				let chart = new frappe.Chart( "#frost-chart", { // or DOM element
				data: {
				labels: ["12am-3am", "3am-6am", "6am-9am", "9am-12pm",
					"12pm-3pm", "3pm-6pm", "6pm-9pm", "9pm-12am"],

				datasets: [
					{
						name: "Some Data", chartType: 'bar',
						values: [25, 40, 30, 35, 8, 52, 17, -4]
					},
					{
						name: "Another Set", chartType: 'bar',
						values: [25, 50, -10, 15, 18, 32, 27, 14]
					},
					{
						name: "Yet Another", chartType: 'line',
						values: [15, 20, -3, -15, 58, 12, -17, 37]
					}
				],

				yMarkers: [{ label: "Marker", value: 70,
					options: { labelPos: 'left' }}],
				yRegions: [{ label: "Region", start: -10, end: 50,
					options: { labelPos: 'right' }}]
				},

				title: "My Awesome Chart",
				type: 'axis-mixed', // or 'bar', 'line', 'pie', 'percentage'
				height: 300,
				colors: ['purple', '#ffa3ef', 'light-blue'],

				tooltipOptions: {
					formatTooltipX: d => (d + '').toUpperCase(),
					formatTooltipY: d => d + ' pts',
				}
			});
		}

		//push dom elemt to page
		$(frappe.render_template(frappe.labone_page.body,this)).appendTo(this.page.main); 

		//run methods
		total();
		page_chart();
		page_table();

	}
	// end of class

})

// HTML CONTENT

let body = `
		
<div id ="frost-chart"></div>
<div id ="datatable"></div>

			
`;
frappe.labone_page = {
	body: body
}

