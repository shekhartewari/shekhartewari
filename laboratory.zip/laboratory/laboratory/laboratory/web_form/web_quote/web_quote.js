frappe.ready(function() {
	// bind events here
})
console.log("web quote")