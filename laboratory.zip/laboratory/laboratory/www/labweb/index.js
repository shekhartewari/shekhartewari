// import App from './App.vue'

import Vuetify from 'vuetify'
new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    data:{
      
    },   
    // render: h => h(App),
      
    })
  
    
    
  

// var alpha= document.getElementById('app')  


