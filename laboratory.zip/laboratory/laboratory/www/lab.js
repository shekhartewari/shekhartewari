
console.log("loaded");
function setURL(url){
    document.getElementById('iframe_a').src = url;
    setMargin();
    // document.querySelectorAll(".main-content-inner")[0].style.display='none';
 
   
  
   
    
//    console.log(y.document.body)
  
    // var iframe_body=y.getElementsByTagName("container")[0];
    
    // if (y.document)y = y.document;
   

  
};

function unsetURL(){
    document.querySelectorAll(".main-content-inner")[0].style.display='block';
    document.getElementById('iframe_a').src = " ";

}
function unsetMargin() {

    var x = document.getElementById("iframe_a");
    var y = (x.contentWindow || x.contentDocument);
    console.log("enter")

 
    var z= y.document.getElementsByClassName("container");
    for(var i =1, il = z.length;i<il;i++){
        z[i].style.marginRight = " 00px";
        console.log(z.length)
     }

}
function autoMargin() {

    var x = document.getElementById("iframe_a");
    var y = (x.contentWindow || x.contentDocument);
    console.log("out")


    var z= y.document.getElementsByClassName("container");
    for(var i =1, il = z.length;i<il;i++){
        z[i].style.marginRight = " 60px";
        console.log(z.length)
     }
    
  

}

var el=document.getElementById('side-main-menu');

el.addEventListener("mouseenter",unsetMargin);
el.addEventListener("mouseleave",autoMargin);