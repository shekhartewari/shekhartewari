import frappe

def get_context(context):
    user=frappe.session.user
    doc=frappe.get_doc('Instrument','INST00025')
    
    list=frappe.get_list('Instrument')
    context={'user':user,'doc':doc,'list':list}

    return context