import frappe

def get_context(context):
    context.mycontext = 'sample'
    return context