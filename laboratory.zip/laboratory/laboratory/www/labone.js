// import App from './App.vue'


new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    data:{
      
    },   
    // render: h => h(App),
      
    })
  
    
    
  

// var alpha= document.getElementById('app')  


