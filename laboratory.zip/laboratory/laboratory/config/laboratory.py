from __future__ import unicode_literals
from frappe import _

def get_data():
    return [
      {
        "label":_("Sample Management"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
              "type": "doctype",
              "name": "Sample",
              "label": _("Sample"),
              "description": _("Samples to be processed."),
            },
            {
              "type": "doctype",
              "name": "Sample Point",
              "label": _("Sample Point"),
              "description": _("Sample Point"),
            },
            {
              "type": "doctype",
              "name": "Sample Matrix",
              "label": _("Sample Matrix"),
              "description": _("Sample Matrix"),
            },
            {
              "type": "doctype",
              "name": "Sample Type",
              "label": _("Sample Type"),
              "description": _("Sample Type"),
            },
            {
              "type": "doctype",
              "name": "Sampling Deviation",
              "label": _("Sampling Deviation"),
              "description": _("Sampling Deviation"),
            },
            {
	    	"type": "page",
	    	"name": "samplepage",
	    	"icon": "icon-sitemap",
	    	"label": _("Sample Page"),
	    	"description": _("Sample Page")
 	     },
            {
              "type": "doctype",
              "name": "Sample Condition",
              "label": _("Sample Condition"),
              "description": _("Sample Condition"),
            }
          ]
      },
      
      {
        "label":_("Workflow Management"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Analysis Categories",
              "label": _("Analysis Categories"),
              "description": _("Analysis Categories"),
            },
            {
               "type": "doctype",
              "name": "Analysis Specifications",
              "label": _("Analysis Specifications"),
              "description": _("Analysis Specifications"),
            },
            {
               "type": "doctype",
              "name": "Dynamic Analysis Specification",
              "label": _("Dynamic Analysis Specification"),
              "description": _("Dynamic Analysis Specification"),
            }
          ]
      },
      {
        "label":_("Instruments"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Instrument",
              "label": _("Instrument"),
              "description": _("Instrument"),
            },
            {
               "type": "doctype",
              "name": "Instrument Type",
              "label": _("Instrument Type"),
              "description": _("Instrument Type"),
            },
            {
               "type": "doctype",
              "name": "Calibration",
              "label": _("Calibration"),
              "description": _("Calibration"),
            }
          ]
      },
       {
        "label":_("Quote & Order"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Quote",
              "label": _("Quote"),
              "description": _("Quote"),
            },
            {
               "type": "doctype",
              "name": "Test Order",
              "label": _("Test Order"),
              "description": _("Test Order"),
            }
          ]
      },
      {
        "label":_("Containers"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Container",
              "label": _("Container"),
              "description": _("Container"),
            },
            {
               "type": "doctype",
              "name": "Container Type",
              "label": _("Container Type"),
              "description": _("Container Type"),
            },
            {
               "type": "doctype",
              "name": "Preservation",
              "label": _("Preservation"),
              "description": _("Preservation"),
            }
          ]
      },
      {
        "label":_("Storage"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Storage Location",
              "label": _("Storage Location"),
              "description": _("Storage Location"),
            },
            {
               "type": "doctype",
              "name": "Sample Point",
              "label": _("Sample Point"),
              "description": _("Sample Point"),
            }
          ]
      },
           {
        "label":_("Documents"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "LabAnalyze",
              "label": _("LabAnalyze"),
              "description": _("LabAnalyze"),
            }
          ]
      },
      {
        "label":_("Contacts"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Client",
              "label": _("Client"),
              "description": _("Client"),
            },
            {
               "type": "doctype",
              "name": "Manufacturer",
              "label": _("Manufacturer"),
              "description": _("Manufacturer"),
            },
            {
               "type": "doctype",
              "name": "Suppliers",
              "label": _("Suppliers"),
              "description": _("Suppliers"),
            }
          ]
      },
      
      {
        "label":_("Tools"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Worksheet Template",
              "label": _("Worksheet Template"),
              "description": _("Worksheet Template"),
            },
            {
               "type": "doctype",
              "name": "Attachment Types",
              "label": _("Attachment Types"),
              "description": _("Attachment Types"),
            },            
            {
               "type": "doctype",
              "name": "Rate List",
              "label": _("Rate List"),
              "description": _("Rate List"),
            }
          ]
      },
      {
        "label":_("Calculations"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "ReflexRule",
              "label": _("ReflexRule"),
              "description": _("ReflexRule"),
            },
            {
               "type": "doctype",
              "name": "Reference Definition",
              "label": _("Reference Definition"),
              "description": _("Reference Definition"),
            },
            {
               "type": "doctype",
              "name": "Dynamic Analysis Specification",
              "label": _("Dynamic Analysis Specification"),
              "description": _("Dynamic Analysis Specification"),
            }
          ]
      },
      {
        "label":_("Master"),
        "icon": "octicon octicon-briefcase",
        "items": [
            {
               "type": "doctype",
              "name": "Rate Master",
              "label": _("Rate Master"),
              "description": _("Rate Master"),
            },
            {
               "type": "doctype",
              "name": "Reagent Master",
              "label": _("Reagent Master"),
              "description": _("Reagent Master"),
            },
            {
               "type": "doctype",
              "name": "Analysis Master",
              "label": _("Analysis Master"),
              "description": _("Analysis Master"),
            },
            {
               "type": "doctype",
              "name": "Profile Master",
              "label": _("Profile Master"),
              "description": _("Profile Master"),
            }
          ]
      }
  ]
