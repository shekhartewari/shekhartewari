# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from . import __version__ as app_version

app_name = "laboratory"
app_title = "Laboratory"
app_publisher = "Shekhar"
app_description = "SLIM APP"
app_icon = "octicon octicon-file-directory"
app_color = "grey"
app_email = "admin@slims.com"
app_license = "MIT"

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
app_include_css = [
  
    # "/assets/laboratory/css/bootstrap.min.css",
    # "/assets/laboratory/css/font-awesome.min.css",
    # "/assets/laboratory/css/owl.carousel.min.css",
    # "/assets/laboratory/css/slicknav.min.css",   
    # "/assets/laboratory/css/typography.css",
    # "/assets/laboratory/css/themify-icons.css",
    # # "/assets/laboratory/css/styles.css",
    # "/assets/laboratory/css/responsive.css",
    # "/assets/laboratory/css/metisMenu.css",
    # "/assets/laboratory/css/default-css.css"
    
]

app_include_js = [
	# "assets/laboratory/js/bootstrap.min.js",
	# "assets/laboratory/js/jquery.slicknav.min.js",
	# "assets/laboratory/js/jquery.slimscroll.min.js",
	# "assets/laboratory/js/metisMenu.min.js",
	# "assets/laboratory/js/owl.carousel.min.js",  
    # "assets/laboratory/js/popper.min.js",
    # # "assets/laboratory/js/vendor/jquery-2.2.4.min.js",
    # "assets/laboratory/js/vendor/modernizr-2.8.3.min.js",
    # "assets/laboratory/js/bar-chart.js",
    # # "assets/laboratory/line-chart.js",	
    # # "assets/laboratory/pie-chart.js",
    # "assets/laboratory/js/plugins.js",
    # # "assets/laboratory/js/scripts.js",
    # "assets/laboratory/js/popper.js"
		


]

# include js, css files in header of web template
# web_include_css = "/assets/laboratory/css/laboratory.css"
# web_include_js = "/assets/laboratory/js/laboratory.js"

# include js in page
# page_js = {"page" : "public/js/file.js"}
page_js = {"mylabpage" : "public/js/laboratory.js"}


# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
#	"Role": "home_page"
# }

# Website user home page (by function)
# get_website_user_home_page = "laboratory.utils.get_home_page"

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Installation
# ------------

# before_install = "laboratory.install.before_install"
# after_install = "laboratory.install.after_install"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "laboratory.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
#	}
# }

# Scheduled Tasks
# ---------------

# scheduler_events = {
# 	"all": [
# 		"laboratory.tasks.all"
# 	],
# 	"daily": [
# 		"laboratory.tasks.daily"
# 	],
# 	"hourly": [
# 		"laboratory.tasks.hourly"
# 	],
# 	"weekly": [
# 		"laboratory.tasks.weekly"
# 	]
# 	"monthly": [
# 		"laboratory.tasks.monthly"
# 	]
# }

# Testing
# -------

# before_tests = "laboratory.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "laboratory.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "laboratory.task.get_dashboard_data"
# }


