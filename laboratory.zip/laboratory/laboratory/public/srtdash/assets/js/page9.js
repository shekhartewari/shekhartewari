// this is from apps/laboratory/laboratory/public/sbadmin2/js/page9.js
console.log("this is from apps/laboratory/laboratory/public/sbadmin2/js/page9.js");