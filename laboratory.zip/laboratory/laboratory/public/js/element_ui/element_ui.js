import ElementApp from './ElementApp.vue';


// import { Button, Select } from 'element-ui';
// import './file1.js';
frappe.provide('frappe.laboratory');
   // create a namespace within the Frappe instance
// Vue.component(Button.name, Button);
// Vue.component(Select.name, Select);

frappe.laboratory.ExportTool = class {   // create a glue class, wich will manage your Vue instance
        constructor({ parent }) {
                this.$parent = $(parent);
                this.page = parent.page;
                this.setup_header();
                this.make_body();       
        }
        make_body() {
                this.$export_tool_container = this.$parent.find('.layout-main');  
                // this.$export_tool_container = this.$parent.find('.sidebar-menu');  
                // this.$export_tool_container = this.$parent.find('.page-head');  
                this.vue = new Vue({
                        el: this.$export_tool_container[0],
                        
                        data: {
                                
                        },
                        render: h => h(ElementApp),
                });
                
        }
        setup_header() {
        }
        
};
