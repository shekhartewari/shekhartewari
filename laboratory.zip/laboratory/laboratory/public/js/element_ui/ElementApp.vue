<template>
        <div>
                <br><Sidebar-collapse>SidebarCollapse</Sidebar-collapse>
                {{ some_data }}<br /><ButtonCounter :count="505"></ButtonCounter>
                <br> {{ some_else_data }}<br /><Sample :count1="50"></Sample>
            
                <br><Slider>Slider</Slider>
                <br><Notification> Notification </Notification  > 
                <br><CustomizableTransfer>CustomizableTransfer</CustomizableTransfer>
                <br> <Alert>Alerter</Alert>
                <br><Drawer>Drawer</Drawer>
                
                <br><Steps>Steps</Steps>
                <br><Table >Table</Table> 
                <br><Form-basic>Form-Basic</Form-basic>
                <br><Cascader>Cascader</Cascader>

        
        </div>
        
</template>

<script>
        import ButtonCounter from './components/ButtonCounter.vue'
        import Sample from './components/Sample.vue'
        import Table from './components/Table.vue'
        import Slider from './components/Slider.vue'
        import Notification from './components/Notification.vue'
        import CustomizableTransfer from './components/CustomizableTransfer.vue'
        import Alert from './components/Alert.vue'
        import Drawer from './components/Drawer.vue'
        import SidebarCollapse from './components/SidebarCollapse.vue'
        import Steps from './components/Steps.vue'
        import FormBasic from './components/FormBasic.vue'
        import Cascader from './components/Cascader.vue'


     

        export default {
                name: "ElementApp",
                data: function () {
                        return {
                                // some_data: 'from ButonCounter.vue via ToolRoot.vue',
                                some_else_data: 'from Sample.Vue vua 2622 Toolroot.vue',
                                some_data: frappe.user.name                                                                                                 
                        }
                },
                components: {
                                
                        // ButtonCounter,
                        Sample,
                        // Table,
                        Slider,
                        // Notification,
                        // CustomizableTransfer,
                        Alert,
                        Drawer,
                        // SidebarCollapse,
                        Steps,
                        // FormBasic,
                        Cascader

                       
                }
        }
</script>

