<template>
<div>
    <el-radio-group v-model="direction">
  <el-radio label="ltr">left to right</el-radio>
  <el-radio label="rtl">right to left</el-radio>
  <el-radio label="ttb">top to bottom</el-radio>
  <el-radio label="btt">bottom to top</el-radio>
</el-radio-group>

<el-button @click="drawer = true" type="primary" style="margin-left: 16px;">
  open
</el-button>

<el-drawer
  title="Drawer for Details"
  :visible.sync="drawer"
  :direction="direction"
  :before-close1="handleClose">
  <span>{{frappe.session.user}}</span>
  <input type="button" value="ok">
  <Slider>Slider</Slider>

  <steps></steps>
  <notification></notification>
  <cascader></cascader>
 
  
</el-drawer>

</div>
    
</template>


<script>
import Cascader from './Cascader.vue';

import Notification from './Notification.vue';
import Slider from './Slider.vue';
import Steps from './Steps.vue';

  export default {
    data() {
      return {
        drawer: false,
        direction: 'rtl',
      };
    },
    methods: {
      handleClose(done) {
        this.$confirm('Are you sure you want to close this?')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      }
    },
    components: {
        Slider,   
        
        Steps,
        Notification,
        Cascader }
  };
</script>