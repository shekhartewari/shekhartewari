<template>
     <button v-on:click="count1++">Sample 2count — {{ count1 }}</button>

</template>

<script>
        export default {
                props: ['count1'],
                data: function () {
                        return {
                                count1: 0
                                
                        }
                }
        }
</script>
