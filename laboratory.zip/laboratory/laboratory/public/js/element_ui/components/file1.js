// frappe.db.get_value('Quote','Q0022','client')
//         .then(r=> {
//             console.log(r.message.client)
//         })
console.log('file1.js loaded')

// frappe.call('ping')
//     .then(r => {
//         console.log(r.responseText.message)
//         // {message: "pong"}
//     })