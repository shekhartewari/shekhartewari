<template>
    <div>
        <el-steps :active="1">
            <el-step title="Step 1" icon="el-icon-edit"></el-step>
            <el-step title="Step 2" icon="el-icon-upload"></el-step>
            <el-step title="Step 3" icon="el-icon-picture"></el-step>
        </el-steps>
    </div>

</template>