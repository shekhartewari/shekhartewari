<template>
        <div>
              <button v-on:click="count++">counter — {{ count }}</button>
              <!-- <input type='text' :value='quote_name()' /> -->
        </div>
       
  
       
</template>

<script>
// import itemx from '/home/shekhar/frappe13/frappe-bench/apps/laboratory/laboratory/laboratory/page/new_page/new_page.js'
// import * as mykey from  './file1.js'
        export default {
                props: ['count'],
                data: function () {
                        return {
                                count: 0
                                
                        }
                }
        }
</script>

