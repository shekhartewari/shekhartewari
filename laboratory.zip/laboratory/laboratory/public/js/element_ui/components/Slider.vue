<template>
  <div class="block">
        <span >Default value</span>
        <el-slider v-model="value1"></el-slider>
  </div>

</template>

<script>
  export default {
    data() {
      return {
        value1: 20,
     
      }
    },
    methods: {
      formatTooltip(val) {
        return val / 100;
      }
    }
  }
</script>