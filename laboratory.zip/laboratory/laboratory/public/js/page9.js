// this is from sites/assets/laboratory/srtdash/assets/js/page9.js
console.log("this is from sites/assets/laboratory/srtdash/assets/js/page9.js");