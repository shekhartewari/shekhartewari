console.log('laboratory.js loaded once')

// import Vue from 'vue';


// Vue.use(VueCompositionApi);

// frappe.db.get_value('Quote','Q0022','amount')
//     .then(r=> {
//         let beta=r.message.amount
//         console.log(r.message.amount)
//         return beta

//     })

// new Vue({
//     el: '#app2',
//     vuetify: new Vuetify(),
//     data () {
//       return {
//         interval: {},
//         value: 0,
//       }
//     },
//     beforeDestroy () {
//       clearInterval(this.interval)
//     },
//     mounted () {
//       this.interval = setInterval(() => {
//         if (this.value === 100) {
//           return (this.value = 0)
//         }
//         this.value += 10
//       }, 1000)
//     },
//   })



