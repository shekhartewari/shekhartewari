// import VueCompositionApi from './@vue/composition-api'

// import VueCompositionAPI from '..//..//../node_modules/@vue/composition-api';
// Vue.use(VueCompositionApi);
// Vue.use(VueCompositionApi);
// export const vueCompositionAPI= new VueCompositionAPI
console.log("composition Api loaded")