


import Base from './examples/wireframes/Base.vue'
// import discord from './examples/wireframes/discord.vue'
import Datatable2 from './components/DataTable2.vue'
import Tab2 from './components/Tab2.vue'
import SearchBrew from './components/SearchBrews.vue'
import Sidebar from './components/Sidebar.vue'
import Splitpanes from './components/Splitpanes.vue'
import Palette from './components/Palette.vue'
import Twolists from './components/DragDrop/two-lists.vue'
import Functional from './components/DragDrop/functional.vue'
import customClone from './components/DragDrop/custom-clone.vue'
// import Bounce from './components/DragDrop/Bounce.vue'
import MathLiveInput from './components/MathLive.vue'
import MyForm from './components/MyForm.vue'


export default [
    
    {name:'sidebar',path: '/', component:Sidebar},
    {name:'base',path: '/base', component:Base},
    {name:'datatable2',path: '/datatable2', component:Datatable2},
    {name:'tab2',path: '/tab2', component:Tab2},
    {name:'brew',path: '/brew', component:SearchBrew},
    {name:'splitpanes',path: '/splitpanes', component:Splitpanes},
    {name:'palette',path: '/palette', component:Palette},
    {name:'two-lists',path: '/two-lists', component:Twolists},
    {name:'functional',path: '/functional', component:Functional},
    {name:'custom-clone',path: '/custom-clone', component:customClone},
    // {name:'bounce',path: '/bounce', component:Bounce},
    {name:'mathlive',path: '/mathlive', component:MathLiveInput},
    {name:'myform',path: '/myform', component:MyForm},

    
   


]