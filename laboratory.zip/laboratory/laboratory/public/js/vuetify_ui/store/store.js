// import Vue from 'vue';
import Vuex from '..//..//../node_modules/vuex/dist/vuex';
// import Vue from 'vue';

Vue.use(Vuex);

export const store = new Vuex.Store({
    namespaced:true,
    state:{
        products:[
            {name:'banana', price:20},
            {name:'shint', price:33},
            {name:'apple', price:45},
            {name:'banandfa', price:280},
            {name:'shints', price:303},
            {name:'apples', price:4895},
        ]
    },
    getters:{
        saleProducts: state => {
            var saleProducts = state.products.map( product =>{
                return{
                  name: "**" +  product.name +"**",
                  price:product.price/3
                }
              });
              return saleProducts;
        }
    },

    mutations:{
        reducePrice: (state,inload)=>{
            state.products.forEach(product => {
                product.price -=inload;
                
            });
        }
    },
    actions: {
        reducePrice: (context,payload) => {
            setTimeout(function(){
                context.commit('reducePrice',payload)
            },2000)
        },
        get_table_func:()=>{
            context.commit('get_list_func')
        },
        get_list_func: function (y) {
            frappe.call({
              method: "frappe.client.get_list",
              args: {
                doctype: y,
                filters: [],
              },
              callback: function (r) {
                r = r.message;
                var result_func;
                result_func = null;
                console.log(r);
                result_func = r;
                return result_func;
              },
            });
        },

		get_table_func: function () {

				frappe.db.get_list('Sample', {
					fields: ['*'],
					filters: {
						'batch': ['>', 0]
					},
					start: 0,
					page_length: 1,
					// as_list:'True'
				})
					.then(r => {
						console.log(r);
			
						let i;
						let columns = [];							
						let data = [];
						let select_data = [];
						const entriesmap = new Map(Object.entries(r));
						// const keysmap = new Map(Object.keys(r));
						// const valuesmap= new Map(Object.values(r));
						// console.log(keysmap);
						console.log(entriesmap);
						for (let [record, value] of entriesmap) {
							let datalist = [];
							// console.log(record,value);
							// console.log(value);
							const arr2= new Map(Object.entries(value));
							// console.log(arr2);
						for (let [key2,val2] of arr2) {
							let datalist2=[];
							// console.log(key2);
						};
							datalist.push(value.name,value.batch, value.sample_condition, value.nabl, value.date_preserved,value.status);
							data.push(datalist);
							console.log(datalist);
						};
						console.log(data);
						
						columns = [
							{ name: 'Name', id: 'name', editable: true, width: 32, format: value => `${value.fontcolor('red').bold()} ` },
							{ name: 'Batch', editable: false, focusable: true, dropdown: true },//available name,id,editable,resizeable,sortable,focusable,dropdown,width,format
							{ name: 'Sample Condition', editable: false },
							{ name: 'NABL', format: value => `${value.fontcolor('yellow').bold()} ⭐️`, editable: true },
							{ name: 'Date', editable: true },
							{ name: 'Status', format: value => `${value} `, editable: false },
			
						];
			
					
			
			
			
					});
		
			}
    }
})