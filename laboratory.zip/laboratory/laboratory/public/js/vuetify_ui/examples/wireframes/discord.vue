<template >
  <v-app id="discord">
    <!-- <v-system-bar app> v-system-bar
      <v-spacer>spacer</v-spacer>

      <v-icon>mdi-square</v-icon>

      <v-icon>mdi-circle</v-icon>

      <v-icon>mdi-triangle</v-icon>
    </v-system-bar> -->

    <v-app-bar app clipped-right flat height="72" color="pink lighten-4">
      <v-spacer></v-spacer>

      <v-responsive max-width="156">
        <v-text-field dense flat hide-details rounded solo-inverted
          >v-text-field</v-text-field
      > </v-responsive
      >v-app-bar
    </v-app-bar >
    <v-divider></v-divider>
    <br />
     <!-- <Tree-view></Tree-view> -->
  
  
    <!-- <Data-table-3></Data-table-3> -->
    

    <v-divider></v-divider>
    <v-navigation-drawer mb-4 expand-on-hover v-model="drawer" app>
      <v-list>
        <v-list-item link v-for="item in items" :key="item.title">
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      
    </v-navigation-drawer>
   

    <v-navigation-drawer expand-on-hover app clipped right>
      <v-list color="blue lighten-4">
        <v-list-item v-for="n in computed_list" :key="n" link>
          <v-list-item-content>
            <v-list-item-title>{{ n.name }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      <v-divider></v-divider>

      <v-list color=" teal lighten-3">
        <v-list-item v-for="n in computed_list" :key="n" link>
          <v-list-item-content>
            <v-list-item-title>{{ n.name }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-main>
      <input type="text" yellow />
      <v-btn @click="get_list_func('Sample')">get_list_func()</v-btn>
      <v-btn @click="get_biglist_func()">get_biglist_func()</v-btn>
      <!-- <v-btn @click="get_list_exp">get_list_exp</v-btn>
      <v-btn @click="get_list_comp_prop">get_list_comp_prop</v-btn> -->
    </v-main>

    <v-footer app color="yellow" height="72" inset>
      Sample Client User DocType
      <v-text-field
        v-model="x_comp"
        background-color="red lighten-5"
        dense
        flat
        hide-details
        rounded
        solo
      ></v-text-field>
      <v-text-field
        v-model="in_exp"
        background-color="red lighten-5"
        dense
        flat
        hide-details
        rounded
        solo
      ></v-text-field>
    </v-footer>
  </v-app>
</template>

<script>
import DataTable3 from "../../components/DataTable3.vue";
import DataTable2 from "../../components/DataTable2.vue";
import TreeView from "../../components/TreeView.vue";
let result_comp = "water";

let result_func = "suger";

let computed_list = [];
let func_list = [];
let list_at_start = [];
export default {
  components: {
    DataTable3,
    DataTable2,
    TreeView,
  },
  name: "Discord",
  methods: {
    // CLICKABLE FUNCTIO N

    get_list_func: function (y) {
      frappe.call({
        method: "frappe.client.get_list",
        args: {
          doctype: y,
          filters: [],
          fields: ["*"],
        },
        callback: function (r) {
          r = r.message;
          result_func = null;
          console.log(r);
          result_func = r;
          return result_func;
        },
      });
    },
    // RUN_AS_EXPRESSION start
    get_list_exp: frappe.call({
      method: "frappe.client.get_list",
      args: {
        doctype: "DocType",
        filters: { module: "Laboratory" },
      },
      callback: function (r) {
        list_at_start.length = 0;
        result_comp = r.message;
        result_comp.forEach((element) => {
          list_at_start.push(element);
        });
        // console.log(list_at_start);
        return list_at_start;
      },
    }),
    get_biglist_func: function () {
      frappe.db
        .get_list("Sample", {
          fields: ["*"],
          filters: {
            // batch: [">", 0],
          },
          start: 0,
          page_length: 1,
          // as_list:'True'
        })
        .then(function(arr) {
          console.log(arr);
          let prop="name"
          let extractedValue = arr.map((item) => item[prop]);
          console.log(extractedValue)
          return extractedValue;
         
        });
    },
    // program to extract value as an array from an array of objects

    extractValue: function (arr, prop) {
      // extract value from property
      let extractedValue = arr.map((item) => item[prop]);

      return extractedValue;
    },

    // RUN_AS_EXPRESSION end
  },
  data() {
    return {
      items: [
        { title: "Home", icon: "mdi-home-city" },
        { title: "Sample", icon: "mdi-account " },
        { title: "Batch Process", icon: "mdi-domain" },
        { title: "Instruments", icon: "mdi-arrow-up-bold-box-outline" },
        { title: "Chemicals", icon: "mdi-account" },
        { title: "Glassware", icon: "mdi-message-text" },
        { title: "Clients", icon: "mdi-home-city" },
        { title: "Reports", icon: "mdi-email" },
        { title: "Quality", icon: "mdi-dialpad" },
      ],
      drawer: null,

      xd: "Sample",
      x_comp: "Client",
      x_exp: "Quote",
      computed_list: computed_list,
      list_at_start: list_at_start,
      result_func:result_func,
    };
  },

  // COMPUTED PORPERTY ( RUNS BY INPUT) on console
  computed: {
    get_list_comp_prop: function () {
      frappe.call({
        method: "frappe.client.get_list",
        args: {
          doctype: this.x_comp,
          filters: {},
        },
        callback: function (r) {
          computed_list.length = 0;
          result_comp = r.message;
          result_comp.forEach((element) => {
            computed_list.push(element);
          });
          console.log(computed_list);
          return computed_list;
        },
      });
    },
  },
};
</script>

