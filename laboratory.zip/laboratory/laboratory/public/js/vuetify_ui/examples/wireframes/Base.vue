<template>
  <v-app id="inspire_base">
    <v-main>
      <v-card fixed width="100%" height="250px"  id="tab1">
        <data-table-2
          v-on:emit_selected="updateListsimple($event)"
          v-on:emit_selected_item="updateitem($event)"
          v-bind:doctype="doctype"
          v-bind:doctyp2="doctype"
        >
        </data-table-2>        
        
      </v-card>
      <v-divider inset></v-divider>
      <v-card  height="15%" width="49.5%" color="pink lighten-5" id="tab2">
        <tab-2 v-bind:selected="selected" v-bind:selected_item="selected_item" v-bind:doctyp3="doctype"></tab-2>
      </v-card>       
      <v-card color="green darken-5" width="25.5%" height="45%" id="tab3">
        <two-lists v-bind:select_aliquot="select_aliquot"></two-lists>
      </v-card>
      <v-spacer></v-spacer>    
      <v-card width="50%" height="45%" color="teal lighten-3" id="tab4">
       <data-table-3></data-table-3>
      </v-card>
    </v-main>
  </v-app>
</template>

<script>
let selected = [];
let select_aliquot = [];
let selected_item = "";
console.log("Base imported");
import DataTable2 from "../../components/DataTable2.vue";
import DataTable3 from '../../components/DataTable3.vue';
import TwoLists from "../../components/DragDrop/two-lists.vue";
import Tab2 from "../../components/Tab2.vue";


export default {
  components: {
    DataTable2,
    Tab2,
    TwoLists,
    DataTable3,

    // SearchBrew,
  },
  name: "Base",
  props: ["doctype"],
  methods: {
    updateListsimple: function (param) {
      this.selected = param;
     
      select_aliquot = [];
      select_aliquot.length = 0;
      for (let i = 0; i < param.length; i++) {
        
        this.select_aliquot[i].name = param[i].name;
        this.select_aliquot[i].id = i;
        select_aliquot.push(this.select_aliquot[i].name);
        select_aliquot.push(this.select_aliquot[i].id);
      }
      return this.selected;
    },
    updateitem: function(param){
      this.selected_item=param;
      
  
    },
    // function to make list from object filtered by key
    // filtered: function (arr, obj) {
    //   const filteredByKey = Object.fromEntries(
    //     Object.entries(obj).filter(function ([key, value]) {
    //       for (let i = 0; i < arr.length; i++) {
    //         if (key === arr[i]) return key;
    //       }
    //     })
    //   );
      

    //   return filteredByKey;
    // },
  },
  data() {
    return {
      drawer: null,
      selected: selected,
      selected_item:selected_item,
      // select_aliquot:select_aliquot,
      select_aliquot: [
        { name: " ", id: 1 },
        { name: " ", id: 2 },
        { name: " ", id: 3 },
        { name: " ", id: 4 },
        { name: " ", id: 5 },
      ],
      doctype: this.doctype,
    };
  },
};
</script>
<style>
.v-main {
  padding-top: 0px;
}
#tab11,
#tab2 {
  margin-top: 0px;
  position: fixed;
  margin-left:0.5%;
}
#tab3 {
  margin-top: 0px;
  position: fixed;
  margin-left: 50.5%;
  
}
#tab4 {
  margin-top: 0px;
  position: fixed;
  margin-left: 50.5%;
  
}
#myappbar {
  background-color: rgb(0, 183, 255);
}
</style>
