window.process = {
        env: {
                NODE_ENV: 'development'
        }
};
import VueRouter from 'vue-router'
import Routes from '../vuetify_ui/routes.js';
import VuetifyApp from './VuetifyApp.vue';
import { store } from '../vuetify_ui/store/store.js';
import Splitpanes from '../../node_modules/splitpanes';
// import { ref } from './VueComposition/composition.js'

// console.log(VueCompositionAPI)

// import Vuetify from 'vuetify/es5/components/*'
// import Vuetify from '../../node_modules/vuetify/dist/vuetify'
// import Vue from 'vue';
// import { Vuetify } from './vuetify.js';
// import VueCompositionApi from '@vue/composition-api/index'

// Vue.use(VueCompositionApi)

// console.log(VueCompositionAPI)
frappe.provide('frappe.laboratory');
frappe.laboratory.VeutifyTool = class {   // create a glue class, wich will manage your Vue instance
        constructor({ parent }) {
                this.$parent = $(parent);
                this.page = parent.page;
                this.setup_header();
                this.make_body();
        }
        make_body() {
                this.$vuetify_container = this.$parent.find('.layout-main');
                // this.$export_tool_container = this.$parent.find('.sidebar-menu');  
                // this.$export_tool_container = this.$parent.find('.page-head');  
                // this.$vuetify_container = this.$parent.find('.html,body');  
                Vue.config.devtools = true;  
                
                // console.log(window.VueCompositionAPI);
                // Vue.use(VueCompositionAPI);
                
                Vue.config.productionTip = false;
                // Vue.use(VueGoodTable)
             
                this.vue = new Vue({
                        el: '#body',
                        // el: '#app',
                        vuetify: new Vuetify(),
                        store: store,
                        // VueCompositionApi: VueCompositionApi,
                       
                        router: new VueRouter({
                                routes: Routes,
                                mode: "history",
                                base:"/app/vuetify-page/",
                        }),
                       
                        // reactive:reactive,
                        // toRefs:toRefs,
                        
                        data: {
                                
                                
                        },
                        render: h => h(VuetifyApp),
                })
        }
        setup_header() {
                   // tool to connect to vue-devtools app (electron app) -- START
                   var s = document.createElement("script");
                   s.type = "text/javascript";
                   s.src = "http://localhost:8098";
                   $("body").append(s);
   
                   // tool to connect to vue-devtools app (electron app) --END
        }
};
