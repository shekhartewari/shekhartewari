<template>
  <div id="app">
    <v-dialog v-model="dialog" width="80%">
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="red lighten-2" dark v-bind="attrs" v-on="on" >
          Click Me
        </v-btn>
      </template>

      <div id="iframe-wrapper" :style="iframe.wrapperStyle">
        <v-btn color="green lighten-2"  @click="hide" >
          Hide        </v-btn>
        <iframe
          v-if="loaded"
          :src="iframe.src"
          :style="iframe.style"
          :height="iframe.style.height"
          :width="iframe.style.width"
          frameborder="20"
         
        ></iframe>
      </div>
    </v-dialog>
  </div>
</template>

<script>

export default {
    name:"MyForm",
    methods: {
    hide(){
        frappe.run_serially([
      ()=>console.log("1"),
      ()=>console.log("2")
    ]);
    
      console.log("clicked")
       var iframewrapper = document.getElementById("iframe-wrapper");
       var iframe = iframewrapper.getElementsByTagName("iframe")[0];

       var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
        // innerDoc.querySelectorAll("navbar,navbar-expand,sticky-top").style.display="none";
       innerDoc.getElementsByClassName("navbar")[0].style.visibility="hidden";
       
      //  var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
      //  var iwrapper=innerDoc.getElementsByClassName("page-form")[0];
      
      // var myNodeList = document.querySelectorAll("div");
    // iframe.getElementsByClassName("navbar")[0].style.display="none"
      // var mylist = iframe.contentWindow.cur_list.views_list.list_view.data
      console.log("clicked")
      console.log(innerDoc)
      // var views_list=cur_list.views_list
      // var list_view=views_list.list_view

      // console.log(innerDoc.frappe.views.list_view["List/Sample/Report"].data)
      // console.log(innerDoc.cur_list.views_list.list_view["List/Sample/Report"].data)
      // console.log(list_view["List/Sample/Report"].data)
    },
    },
  data() {
    return {
      loaded: false,
      iframe: {
        src: "http://labone:8000/app/sample/S00004",

        style: null,
        wrapperStyle: null,
      },
    };
  },
  mounted() {
  
    let editor = this.$refs.editor;
    this.iframe.style = {
      position: "relative",
      width: window.innerWidth,
      height: window.innerWidth,
    };
    this.iframe.wrapperStyle = {
      overflow: "auto",
     
    };
    console.log("mounted")
    console.log(window.document.getElementById("app"));
    // console.log(x.getElementsByClassName("navbar")[0])
  // window.document.getElementsById("iframe-wrapper").contentWindow.document.body.getElementsByClassName("navbar").style.display="none"
 
 
    this.loaded = true;
    console.log(this.loaded)
  
 
  },
  
};
</script>%