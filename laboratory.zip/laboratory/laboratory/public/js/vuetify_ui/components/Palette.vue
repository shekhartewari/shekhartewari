<template>
  <div id="palette">
    <div class="board">
      <div class="lane">
        <h2 class="lane-title">Empty</h2>
        <card v-for="card in cards.empty" :key="card.id" @dragover.prevent @drop.prevent="drop">{{
          card.text
        }}</card>
      </div>
      <div class="lane">
        <h2 class="lane-title">Started</h2>
        <card v-for="card in cards.started" :key="card.id" draggable="true"  @dragover.prevent @drop.prevent="drop">{{
          card.text
        }}</card>
      </div>
      <div class="lane">
        <h2 class="lane-title">Finished</h2>
        <card v-for="card in cards.finished" :key="card.id" draggable="true"  @dragstart="startDrag($event,card)">{{
          card.text
        }}</card>
      </div>
      <div class="lane">
        <h2 class="lane-title">Disposed</h2>
        <card v-for="card in cards.disposed" :key="card.id">{{
          card.text
        }}</card>
      </div>
    </div>
  </div>
</template>
<script>
import Card from "./Card.vue";
// import {Container, Draggable} from 'vue-smooth-dnd/dist/vue-smooth-dnd.esm';

export default {
  name: "Palette",
  components: {
    Card,
    // Container,Draggable
  },
  data() {
    return {
      cards: {
        empty: [{ id: 1, text: " Sample 14" }],
        started: [
          { id: 2, text: " Sample 2" },
          { id: 3, text: " Sample 3" },
          { id: 4, text: " Sample 4" },
        ],
        finished: [
          { id: 5, text: " Sample 5" },
          { id: 6, text: " Sample 6" },
          { id: 7, text: " Sample 7" },
        ],
        disposed: [
          { id: 8, text: " Sample 8" },
          { id: 9, text: " Sample 9" },
        ],
      },
     
    };
  },
  methods: {
    // getList: (card) => {
    //   return cards.started.text.filter((card) => card.text == text);
    // },
    // startDrag: (event, card) => {
    //   console.log(card);
    //   event.dataTransfer.dropEffect = "move";
    //   event.dataTransfer.effectAllowed = "move";
    //   event.dataTransfer.setData('itemID',card.id) ;
    // },
    drop: e=> {
        const card_id=e.dataTransfer.getData('card_id');
        const cardton = document.getElementById('card_id')
        cardton.style.display='block';
        e.target.appendChild(cardton)
        console.log(cardton)
    }
  },
};
</script>
<style scoped>
.board {
  display: flex;
  justify-content: flex-start;
}
.lane {
  background: green;
  width: 23rem;
  height: 30rem;
  border-radius: 0.8rem;
  box-shadow: 0 0.1rem 0.2rem 0 rgba(33, 33, 33, 0.1);
  margin: 0 0.8rem;
  padding: 0 0.7rem;
}
.lane-title {
  padding: 0.8rem 0.5rem;
  margin-bottom: 0.6rem;
}
</style>