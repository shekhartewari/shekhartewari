<template>
  <div>
    <v-system-bar dark color="grey darken-2">
      <v-spacer></v-spacer>
      <v-icon>mdi-wifi-strength-3</v-icon>
      <v-icon>mdi-signal-cellular-outline</v-icon>
      <v-icon>mdi-battery-50</v-icon>
      <!-- {{timer()}} -->
      {{ joker() }}
      <span> {{ frappe.session.user }} {{ username }} </span>
    </v-system-bar>
  </div>
</template>
<script>
export default {
  props: ["username"],
  methods: {
    timer() {
      setInterval(function () {
        //  let result=frappe.datetime.now_datetime();
        let result = 3;

        console.log(result);
        return result;
      }, 3000);
    },
    joker() {
      console.log("joker");
    },
  },
};
</script>
