<template>
  <div id="app">
    <h1>Hello Mathematical Equations</h1>

    <p>I wrote $$e^{i\pi} + 1 = 0$$. Can you type it? </p>
    <div style="width:50%;border:#aeaeae;background:#eeeeee">
<MathLiveInput :config="config" v-model="formula" v-on:input="input()">g(x)=</MathLiveInput>

    </div>
      <!-- <div id='output'>{{formula}}</div> -->
  </div>
</template>

<script>
import MathLive from "mathlive";
import MathLiveInput from "./MathLiveInput.vue";

export default {
  name: "app",
  components: {
    MathLiveInput
  },
  data: function() {
    return {
      formula: 'h(x)',
    config:{
      smartMode: true,
      virtualKeyboardMode: "manual",
    }
     }
  },
  mounted: function() {
    MathLive.renderMathInDocument();
  },
  methods: {
    input : function() {
      console.log(this.formula)
    }
  }
};


</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
</style>