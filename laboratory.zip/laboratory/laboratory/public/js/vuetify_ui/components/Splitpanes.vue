<template>
    <splitpanes class="default-theme">
      
    <pane min-size="10">1<br/><em class="specs">I have a min width of 20%</em></pane>
    <pane>
      <splitpanes class="default-theme" horizontal="horizontal">
        <pane min-size="5" max-size="10">2<br/><em class="specs">I have a min height of 15%</em></pane>
        <pane min-size="35" max-size="10"  >
         
          3</pane>
        <pane min-size="10" >4</pane>
      </splitpanes>
    </pane>
    <pane min-size="5" >5</pane>
  
  </splitpanes>
</template>

<script>
import {Splitpanes, Pane} from '../../../node_modules/splitpanes/src/components/splitpanes/index.js'
import '../../../node_modules/splitpanes/dist/splitpanes.css'

export default {
    name: "mysplitpanes",
    components:{
        Splitpanes,
        Pane,
     
    }
}
</script>
<style>
.splitpanes {
  background: linear-gradient(-45deg, #EE7752, #E73C7E, #23A6D5, #23D5AB);
}

.splitpanes__pane {
  box-shadow: 0 0 5px rgba(0, 0, 0, .2) inset;
  justify-content: center;
  align-items: center;
  display: flex;
}

.splitpanes--vertical > .splitpanes__splitter {
  min-width: 6px;
  background: linear-gradient(90deg, #ccc, #111);
}

.splitpanes--horizontal > .splitpanes__splitter {
  min-height: 6px;
  background: linear-gradient(0deg, #ccc, #111);
}
</style>