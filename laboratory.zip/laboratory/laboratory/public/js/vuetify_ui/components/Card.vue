<template>
    <div class="card" id="id" :draggable="draggable" @dragstart="dragStart" @dragover.stop>
        <slot/>    
    </div>
</template>
<script>
export default {
    name:"Card",
    props:["id","draggable"],
    methods :{
        dragStart:e=> {
            const target=e.target
            e.dataTransfer.setData('card_id',target.id);
            setTimeout(()=>{
                target.style.display='none'
            },0)
        }
    }
}
</script>
<style scoped>
npm i -S vuedraggable
.card {
    background: white;
    padding: 1.4rem;
    border-radius: 0.4rem;
    box-shadow:  0 1px 0 rgba(9, 30, 66, .25);
    margin-bottom: .8rem;
    font-size: 1.6rem;
    cursor: pointer;
}
</style>