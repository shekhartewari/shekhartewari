<template>
  <div class="row">
    <div class="col-3">
      <h3>Sample Tray</h3>
      <draggable
        class="dragArea list-group"
        :list="list1"
        :group="{ name: 'people', pull: 'clone', put: false }"
        :clone="cloneSample"
        @change="log"
      >
        <div class="list-group-item" v-for="element in list1" :key="element.id">
          {{ element.name }}
        </div>
      </draggable>
    </div>

    <div class="col-3">
      <h3>Prepare batch</h3>
      <draggable
        class="dragArea list-group"
        :list="list2"
        group="people"
        @change="log"
      >
        <div  class="list-group-item" v-for="element in list2" :key="element.id">
          {{ element.name }}
        </div>
      </draggable>
    </div>

      <div class="col-3">
      <h3>DIscarded</h3>
      <draggable
        class="dragArea list-group"
        :list="list3"
        group="people"
        @change="log"
        
      >
        <div class="list-group-item" v-for="element in list3" :key="element.id">
          {{ element.name }}
        </div>
      </draggable>
    </div>

    <rawDisplayer class="col-3" :value="list1" title="List 1" />

    <rawDisplayer class="col-3" :value="list2" title="List 2" />

    <rawDisplayer class="col-3" :value="list3" title="List 3" />
  </div>
</template>

<script>
import draggable from "vuedraggable";
let idGlobal = 8;
export default {
  name: "customClone",
  display: "Custom Clone",
  order: 3,
  components: {
    draggable
  },
  data() {
    return {
      list1: [
        { name: "Sample S0001", id: 'S0001' },
        { name: "Sample S0002", id: 's0002' },
        { name: "Sample S0003", id: 'S0003' },
        { name: "Sample S0004", id: 'S0004' }
      ],
      list2: [
        { name: "Aliquot 5", id: 5 },
        { name: "Aliquot 6", id: 6 },
        { name: "Aliquot 7", id: 7 }
      ]
      ,
      list3: [
        { name: "Aliquot 5", id: 5 },
        { name: "Aliquot 6", id: 6 },
        { name: "Aliquot 7", id: 7 }
      ]
    };
  },
  methods: {
    log: function(evt) {
      window.console.log(evt);
    },
    cloneSample({ id }) {
      return {
        id: idGlobal++,
        name: `Aliquot ${id}`
      };
    }
  }
};
</script>
<style scoped></style>
