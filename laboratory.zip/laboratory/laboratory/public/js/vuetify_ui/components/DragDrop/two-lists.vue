<template>

  <div class="row">
    
    
    <div class="col-3">
       <v-select
          v-model="select"
          dense
          :items=[1,2,3,4,5,6,7,8,9,10]
          item-text="state"
          item-value="abbr"
          label="Select"
          persistent-hint
          return-object
          single-line
          
        ></v-select>
      <div class="group-head">Aliquots</div>
      <draggable class="list-group" :list="select_aliquot" group="people" @change="log">
        <div
          class="list-group-item"
          v-for="(element, index) in select_aliquot"
          :key="element.name"
        >
          {{ element.name }} 
        </div>
      </draggable>
    </div>

    <div class="col-3">
      <div class="group-head">Batch1</div>
      <draggable class="list-group" :list="list2" group="people" @change="log">
        <div 
          class="list-group-item" 
          v-for="(element, index) in list2"
          :key="element.name"
        >
          {{ element.name }} 
        </div>
      </draggable>
    </div>
        <div class="col-3">
      <div class="group-head">Batch2</div>
      <draggable class="list-group" :list="list3" group="people" @change="log">
        <div 
          class="list-group-item" 
          v-for="(element, index) in list3"
          :key="element.name"
        >
          {{ element.name }} 
        </div>
      </draggable>
    </div>
    <!-- <rawDisplayer class="col-3" :value="select_aliquot" title="List 1" />
    <rawDisplayer class="col-3" :value="list2" title="List 2" /> -->
  </div>
</template>
<script>
import draggable from "vuedraggable";

export default {
  name: "two-lists",
  display: "Two Lists",
  props:   ['select_aliquot'],
  
  order: 1,
  components: {
    draggable,
  },
  data() {
    return {
      list1: [
        { name: "John", id: 1 },
        { name: "Joao", id: 2 },
        { name: "Jean", id: 3 },
        { name: "Jonathan", id: 4 },
      ],
      list2: [
        { name: "Gerard", id: 5 },
        { name: "Edgard", id: 6 },
        { name: "Philip", id: 7 },
      ],
      list3: [
        { name: "blank", id: 5 },
        
      ],
    };
  },
  methods: {
    add: function () {
      this.list.push({ name: "Juan" });
    },
    replace: function () {
      this.list = [{ name: "Edgard" }];
    },
    clone: function (el) {
      return {
        name: el.name + " cloned",
      };
    },
    log: function (evt) {
      window.console.log(evt);
    },
  },
};
</script>
<style scoped>
.list-group-item {
  padding: 2px;
  background-color:khaki;
 
}
.list-group{
   margin-left: 15px;
}
.group-head{
  margin-left: 15px;
  color: white;
  font: bolder;
  font-size: 18px;

}
.row{
  width: 600px;
}
.v-select{
  width: 5px;
  padding: 0px;
  margin:14px;
}
</style>
