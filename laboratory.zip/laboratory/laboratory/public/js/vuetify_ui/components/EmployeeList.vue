<template>
<div>
    
   
    <h1>Employee List</h1>
    <!-- {{html1}}  -->
    <h2>{{beta}}</h2>
    <h3>{{list}}</h3>
 
</div>
    
</template>
<script>

// import Vue from 'vue';
// import VueAxios from 'vue-axios';
// import axios from 'axios';
// Vue.use(VueAxios,axios)
// import FrappeClient from 'frappeclient';
export default {
    name:"EmployeeList",
    data()
    {
        return {
            // html1:undefined,
            beta:undefined,
            list:undefined,
        }
    },
    mounted()
    {
        // axios.get("http://localhost:8000/api/resource/Sample")
        // .then(resp=>{
        //     this.html1=resp.data.data
        //     console.log(resp.data.data)
        // }),
        frappe.db.get_value('Quote','Q0021','amount')
            .then(r=> {
            this.beta=r.message.amount
            console.log(r.message.amount)
           
        }),
        frappe.db.get_list('Instrument')
            .then(r=>{
                this.list=r
                console.log(r)
            })
    }
}
</script>