<template>
  <div class="brews">
    <h2>Brew Search</h2>
   
      <form @submit.prevent="submitted">
        <input type="text" v-model="val2" />
        <button>Submit</button>
       
      </form>
  
    
      <div >
        <ul class="search-results" v-for="brewery in list2" :key="brewery.id" >
          <li>
            <span class="title">Name:</span>
            <span class="brew">{{ brewery.name }}</span>
          </li>
          <li>
            <span class="title"> Street:</span>
            <span class="brew">{{ brewery.street }}</span>
          </li>
          <li>
            <span class="title"> City:</span>
            <span class="brew">{{ brewery.city }}</span>
          </li>
          <li>
            <span class="title"> Zip:</span>
            <span class="brew">{{ brewery.postal_code }}</span>
          </li>
        </ul>
      </div>
    
  </div>
</template>
<script>
// import Vue from 'vue/types/umd';
// Vue.use(VueCompositionApi)
// const {ref} = VueCompositionAPI;
// import {ref} from '@vue/composition-api'
import useBrewList from '../composables/use-brew-list.js'
let list2=[];
export default {
  setup() {
   
    // const { ref, reactive } = VueCompositionAPI; 
    // const val2 = ref("");
    // const breweries = reactive({ list2: [] });
    // const submitted = async function () {
    //   const response = await fetch(
    //     `https://api.openbrewerydb.org/breweries/?by_name=${val2.value}`
    //   );
    //   const json = await response.json();
      
    //   breweries.list2 = json;
    //   console.log(breweries.list2);
    //   console.log(val2)
    //   console.log(breweries)
     
    // };
    // console.log(list2)
    const {val2, list2, submitted} = useBrewList();

    return { val2, list2, submitted };
  },
  name: "SearchBrew",
  // data() {
  //   return {
  //     val: "",
  //     breweries: [],
  //   };
  // },
  // methods: {
  // submitted: async function () {
  //   const response = await fetch(
  //     `https://api.openbrewerydb.org/breweries/?by_name=${this.val}`
  //   );
  //   const json = await response.json();
  //   console.log(json);
  //   this.breweries = json;
  // },
  // get_meta: function () {
  //   let get_meta_list = [];
  //   frappe.call({
  //     method:
  //       "laboratory.laboratory.page.vuetify_page.vuetify_page.get_meta_wl",
  //     args: {
  //       doctype: "Client",
  //     },
  //     callback: function (r) {
  //       r = r.message;
  //       get_meta_list.length = 0;

  //       r.forEach((element) => {
  //         get_meta_list.push(element);
  //       });

  //       console.log(get_meta_list);
  //       return get_meta_list;
  //     },
  //   });
  // },
  // },
};
</script>
<style >
.search-results {
  display: flex;
  width: 600px;
  text-align: left;
}
.brews {
  max-width: 1024px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin: 0 auto;
}
ul {
  list-style-type: none;
  width: 100%;
}
li {
  display: flex;
  justify-content: space-between;
}
.brew {
  font-weight: bold;
}
</style>