<template >
  <v-card width="100%" height="50%" >
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
      ></v-text-field>
    </v-card-title>
    <v-data-table
      dense
      fixed
      v-model="selected"
      :headers="headers"
      :items="p"
      :single-select="singleSelect"
      item-key="name"
      show-select
      class="elevation-1"
      :search="search"
      :items-per-page="5"
      @input="hclick(`input`)"
      @click:row="hclick(`click`)"
      @dblclick:row="hclick(`dblclick`)"
   
      
    >
      <template v-slot:top> </template>
    </v-data-table>
  </v-card>
</template>

<script>
import get_functions from "../composables/labFunctions.js";
export default {
  name: "DataTable3",
   setup() {
    const { ref } = VueCompositionAPI;
    const { get_meta_list,meta_list, get_meta } = get_functions();
    


    const hclick = function (r) {
    // get_meta('Instrument')
      console.log(r)
     
      // console.log(final.value);
    };
 
    const p = ref(get_meta_list);
    return { get_meta_list,meta_list, get_meta, hclick, p };
  },
  data() {
    return {
      singleSelect: false,
      selected: [],
      search: "",

      headers: [
        {
          text: "Title ",
          align: "start",
          sortable: false,
          value: "title",
        },
        { text: "Fieldname", value: "fieldname" },
        { text: "FieldType", value: "fieldtype" },
       
      ],
     
      
    };
  },
};
</script>

