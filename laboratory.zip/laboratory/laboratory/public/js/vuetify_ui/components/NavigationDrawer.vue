<template>
<div class="ma-0 pa-0">
  <v-card height="100%" width =15%>
    <v-navigation-drawer
      relative
      permanent
      expand-on-hover        >
      <template v-slot:prepend>
  
      </template>
      
      <v-list dense>
        <v-list-item link
          v-for="item in items"
          :key="item.title"
        >
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      
    </v-navigation-drawer>
    
      <p class="ma-8 pa-8"> <data-table3></data-table3>Text two</p>
      
  <span class="ma-8 pa-8">  Text three</span>
  
  <v-divider></v-divider>
   <span class="ma-8 pa-8">  Text Four</span>
  
  </v-card>
</div>
</template>

<script>

  export default {
    name:'NavigationDrawer',
    components:{
        // DataTable3
    },
    data () {
      return {
        items: [
          { title: 'Home', icon: 'mdi-home-city' },
          { title: 'My Account', icon: 'mdi-account' },
          { title: 'Users', icon: 'mdi-account-group-outline' },
           { title: 'Home', icon: 'mdi-home-city' },
          { title: 'My Account', icon: 'mdi-account' },
          { title: 'Users', icon: 'mdi-account-group-outline' },
           { title: 'Home', icon: 'mdi-home-city' },
          { title: 'My Account', icon: 'mdi-account' },
          { title: 'Users', icon: 'mdi-account-group-outline' },
        ],
      }
    },
  }
</script>
