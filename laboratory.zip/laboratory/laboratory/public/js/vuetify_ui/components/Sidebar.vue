<template>
  <v-card class="mx-auto overflow-hidden" height="720">
    <v-app-bar id="myappbar" app clipped-left dense class="teal lighten-5">
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title>Lab App Bar</v-toolbar-title>
      <v-tabs>
        
        <v-tab @click="docfun('Sample')">Sample</v-tab>
        <v-tab @click="docfun('Aliquots')">Aliquots</v-tab>
        <v-tab @click="docfun('Batches')">Batch</v-tab>
        <v-tab @click="docfun('Quote')">Quote</v-tab>
        <v-tab @click="docfun('Quote elements')">Quote Elements</v-tab>

        <v-tab @click="docfun('Instrument')">Instrument</v-tab>
        <v-tab @click="docfun('Lead')">Lead</v-tab>
        <v-tab @click="docfun('Analysis Specifications')">Analysis</v-tab>
        <v-tab @click="docfun('Product Group')">Product Group</v-tab>
        <v-tab text>SOP</v-tab>
      </v-tabs>
       <v-btn class="ma-1" dark small color="cyan">
          <v-icon dark> mdi-plus </v-icon>
        </v-btn>

        <v-btn class="ma-1" dark small color="cyan">
          <v-icon dark> mdi-heart </v-icon>
        </v-btn>

        <v-btn class="ma-1" dark color="cyan" small>
          <v-icon dark> mdi-minus </v-icon>
        </v-btn>

        <v-btn class="ma-1" dark color="cyan" small>
          <v-icon dark> mdi-format-list-bulleted-square </v-icon>
        </v-btn>

        <v-btn class="ma-1" dark color="cyan" small>
          <v-icon dark> mdi-pencil </v-icon>
        </v-btn>

        <v-btn class="ma-1" dark small color="cyan">
          <v-icon dark> mdi-android </v-icon>
        </v-btn>
      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>
      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>
    <!-- <v-card color="red lighten-4" flat height="8px" dense class="ma-12">
      <v-toolbar dense>
       
      </v-toolbar>
    </v-card> -->

    <v-navigation-drawer
      app
      v-model="drawer"
      clipped
      permanent
      expand-on-hover
      class="teal lighten-5"
    >
      <!-- -->

      <v-list nav dense>
        <div v-for="(link, i) in links" :key="i">
          <v-list-item
            v-if="!link.subLinks"
            :to="link.to"
            :active-class="color"
            class="v-list-item"
          >
            <v-list-item-icon>
              <v-icon>{{ link.icon }}</v-icon>
            </v-list-item-icon>

            <v-list-item-title v-text="link.text" />
          </v-list-item>

          <v-list-group
            v-else
            :key="link.text"
            no-action
            :prepend-icon="link.icon"
            :value="false"
          >
            <template v-slot:activator>
              <v-list-item-title>{{ link.text }}</v-list-item-title>
            </template>

            <v-list-item
              v-for="sublink in link.subLinks"
              :to="sublink.to"
              :key="sublink.text"
            >
              <v-list-item-icon>
                <v-icon>{{ sublink.icon }}</v-icon>
              </v-list-item-icon>
              <v-list-item-title>{{ sublink.text }}</v-list-item-title>
            </v-list-item>
          </v-list-group>
        </div>
      </v-list>
    </v-navigation-drawer>
    <Base v-bind:doctype="doctype"></Base>
  </v-card>
</template>

<script>
import Base from "../examples/wireframes/Base.vue";

export default {
  data: () => ({
    drawer: false,
    doctype: this.doctype,
    links: [
      {
        to: "/Sample",
        icon: "mdi-view-dashboard",
        text: "Dashboard",
        fn: "somefunction()",
      },
      {
        icon: "mdi-flask",
        text: "Templates",
        subLinks: [
          {
            text: "View Templates",
            to: "/templates",
            icon: "mdi-view-list",
          },
          {
            text: "New Template",
            to: "/templates/new",
            icon: "mdi-plus",
          },
        ],
      },
      {
        icon: "mdi-test-tube",
        text: "Sample",
        subLinks: [
          {
            text: "Sample awaited",
            to: "/sample",
            icon: "mdi-test-tube-empty",
          },
          {
            text: "Sample for verification",
            to: "/sample",
            icon: "mdi-test-tube-off",
          },
          {
            text: "Sample for Report",
            to: "/sample",
            icon: "mdi-plus",
          },
        ],
      },

      {
        icon: "mdi-gauge",
        text: "Instruments",
        subLinks: [
          {
            text: "Calibrate Instruments",
            to: "/apps",
            icon: "mdi-speedometer",
          },
          {
            text: "Upgrade Instrument",
            to: "/apps",
            icon: "mdi-plus",
          },
          {
            text: "Discard Instrument",
            to: "/apps",
            icon: "mdi-plus",
          },
        ],
      },

      {
        icon: "mdi-book",
        text: "Forms",
        subLinks: [
          {
            text: "View Forms",
            to: "/templates",
            icon: "mdi-view-list",
          },
          {
            text: "Create Report",
            to: "/templates/new",
            icon: "mdi-plus",
          },
        ],
      },
      {
        icon: "mdi-file-chart",
        text: "Reports",
        subLinks: [
          {
            text: "View Reports",
            to: "/templates",
            icon: "mdi-view-list",
          },
          {
            text: "Create Report",
            to: "/templates/new",
            icon: "mdi-plus",
          },
        ],
      },
    ],
  }),
  components: {
    Base,
  },
  methods: {
    docfun: function (x) {
      this.doctype = x;
      console.log("doctype is :" + this.doctype);
      return this.doctype;
    },
  },
};
</script>

<style scoped>
.v-application--is-ltr
  .v-list--dense.v-list--nav
  .v-list-group--no-action
  > .v-list-group__items
  > .v-list-item {
  padding: 0 8px;
}
</style>