<template>
  <v-simple-table dense  light>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">Key</th>
          <th class="text-left">Value</th>
        </tr>
      </thead>

      <!-- {{ get_list_comp_prop }} -->
      <!-- <p>{{selected}}</p> -->
  
      <tbody>
      <!-- <tbody v-for="item in selected" :key="item.name"> -->
     
        <tr v-for="(value,key) in content">
          <td>{{ key}}</td>
          <td>{{ value }}</td>
        </tr>
    
        </tbody>
      <!-- </tbody> -->
    </template>
  </v-simple-table>
</template>

<script>
console.log("list simple loaded");

export default {
  name: "ListSimple",
  props: {
    selected: {
      type: Object,
    },
    content:{
      type: Array,
    }
  },
  methods: {},
  computed: {},

  data() {
    return {
      // computed_list: computed_list,
    };
  },
};
</script>
