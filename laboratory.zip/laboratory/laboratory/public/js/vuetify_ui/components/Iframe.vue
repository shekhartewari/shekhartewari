<template>
  <div>
    <iframe
      :src="`/app/sample/view/report/myCustomReport`"
      width="80%"
      height="300px "
     
      frameborder="0"
      display="block"
      id="iframe"
      
    >
    </iframe>
    <div>
      <button class= green  @click="access()">change</button>
    </div>
    
  </div>
</template>
<script>

console.log('frame loaded')
export default {
    name: 'Iframe',
    methods: {
    access(){
       var iframe = document.getElementById("iframe");
       var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
       var iwrapper=innerDoc.getElementsByClassName("page-form")[0];
      //  console.log(iwrapper);
      var myNodeList = document.querySelectorAll("div");
      // console.log(myNodeList)
      var mylist = iframe.contentWindow.cur_list.views_list.list_view.data
      
      console.log(mylist)
      // var views_list=cur_list.views_list
      // var list_view=views_list.list_view

      // console.log(innerDoc.frappe.views.list_view["List/Sample/Report"].data)
      // console.log(innerDoc.cur_list.views_list.list_view["List/Sample/Report"].data)
      // console.log(list_view["List/Sample/Report"].data)
    },
    changStyl(){
         var iframe = document.getElementById("iframe");
        //  iframe.style.display="flex"
       var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
      //  disable_link=innerDoc.getElementsByTagName("a")   
      //  innerDoc.getElementsByClassName("page-form")[0].style.backgroundColor="red";
      //  innerDoc.getElementsByClassName("navbar")[0].style.display="none";
      //  innerDoc.getElementsByClassName("frappe-list")[0].style.backgroundColor="red";
      //  innerDoc.getElementsByClassName("datatable")[0].style.display="display";
      //  innerDoc.getElementsByClassName("page-head")[0].style.display="ruby";
      //  innerDoc.getElementsByClassName("custom-btn-group")[0].style.display="none";
      //  innerDoc.getElementsByClassName("primary-action")[0].style.display="none";
      //  innerDoc.getElementsByClassName("standard-filter-section")[0].style.display="none";
 
      
      //  i_page_head.style.display="none"
      //  disable_link.style.display="none" 
  console.log("styled")

  // DISABLE LINKS--START
       var x = innerDoc.getElementsByClassName("layout-main-section-wrapper")[0].getElementsByTagName("a");
          var i;
          for (i = 0; i < x.length; i++) {
            x[i].style.color = "blue";
            x[i].removeAttribute("href");
            console.log(x[i])
          } 
  // DISABLE LINKS--END     
  
  
// REFRESH PAGE AFTER LOADING FOR IFRAME TO LOAD--START

	// if (!localStorage.getItem("reload")) {
		/* set reload to true and then reload the page */
	// 	localStorage.setItem("reload", "true");
	// 	location.reload();
	// }
	/* after reloading remove "reload" from localStorage */
	// else {
	// 	localStorage.removeItem("reload");
		// localStorage.clear(); // or clear it, instead
	// }

// REFRESH PAGE AFTER LOADING FOR IFRAME TO LOAD--END
    }
    
  },
}
</script>
<style>
#iframe {
  display: block;
}
</style>