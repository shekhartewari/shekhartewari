<template >
  <div>
    <v-card width="100%" height="100%">
      <v-toolbar dense>
        <v-btn
          v-if="!doctyp2"
          id="db0"
          class="ma-1"
          light
          text
          color="grey"
          small
        >
          <v-icon> mdi-database-remove </v-icon>
        </v-btn>
        <v-btn
          v-if="doctyp2"
          id="db1"
          text
          light
          small
          class="ma-1"
          color="blue"
          @click="btnswitch(`db1`), get_list_func(doctype), get_list_view(doctype)"
        >
          <v-icon dark> mdi-database </v-icon>
        </v-btn>
        <v-btn id="db2" @click="btnswitch(`db5`)" class="ma-1" text small>
          <v-icon dark> mdi-plus </v-icon>
        </v-btn>

        <v-btn id="db3" @click="btnswitch(`db3`)" class="ma-1" text small>
          <v-icon dark> mdi-minus </v-icon>
        </v-btn>

        <v-btn id="db4" @click="btnswitch(`db4`)" class="ma-1" text small>
          <v-icon dark> mdi-format-list-bulleted-square </v-icon>
        </v-btn>

        <v-btn id="db5" @click="btnswitch(`db5`)" text small>
          <v-icon dark> mdi-pencil </v-icon>
        </v-btn>

        <v-btn id="db6" class="ma-1" text small @click="btnswitch(`db6`)">
          <v-icon dark> mdi-android </v-icon>
        </v-btn>
        <v-btn id="db7" @click="btnswitch(`db7`)" class="ma-1" text small>
          <v-icon dark> mdi-heart </v-icon>
        </v-btn>
           <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          dense
          class="ma-4 pt-6"
        ></v-text-field>

        <v-btn @click="emit_selected(selected)">emit</v-btn>
        <v-btn @click="get_meta(doctype)">get_meta</v-btn>
        <!-- <v-btn @click="get_list_func(doctype)">get_list_func</v-btn> -->
        <!-- <v-btn @click="get_list_view(doctype)">get_list_view</v-btn> -->
        <!-- <v-btn @click="get_form_load()">get_form_load</v-btn> -->
        <v-btn @click="get_report_view('Instrument','Report')">get_report_view only</v-btn>
        <v-btn
          @click="get_report_view(get_report_list('Report', 'Instrument Report'))"
          >get_report_view combo</v-btn
        >
        <v-btn
          ref="report_list"
          @click="get_report_list('Report', 'Instrument Report')"
          >get_report_list</v-btn
        >
        <v-btn
          class="ma-1"
          dark
          color="cyan"
          small
          text
          @click:row="get_meta(doctype), get_list_view(doctype)"
        >
          <v-icon dark> mdi-format-list-bulleted-square </v-icon>
        </v-btn>
     
      </v-toolbar>
      <v-data-table
        grid
        dense
        fixed

        v-model="selected"
        :headers="headers"
        :items="result_func"
        :single-select="singleSelect"
        item-key="name"
        show-select
        class="elevation-1"
        :search="search"
        :items-per-page="5"
        footer-props="{}"
        @input="get_list_func(doctype), emit_selected(selected), get_list_view(doctype),get_meta(doctype)"
        @dblclick:row="dblclickRow(item,$event), emit_selected_item(selected_item)"
      >
        <template v-slot:top> </template>
      </v-data-table>
    </v-card>
  </div>
</template>

<script>

import get_functions from '../composables/labFunctions.js'
export default {
  setup(){
    const {result_func,meta_list,get_meta_list,list_view_filter,test_func_result,selected,selected_item,tester,get_list_func,get_meta,emit_selected,emit_selected_item,get_report_list,get_form_load,get_report_view,get_report_view2,get_list_view,btnswitch,dblclickRow} = get_functions();
    console.log("setup done");
 
    return {result_func,meta_list,get_meta_list,list_view_filter,test_func_result,selected,selected_item,tester,get_list_func,get_meta,emit_selected,emit_selected_item,get_report_list,get_form_load,get_report_view,get_report_view2,get_list_view,btnswitch,dblclickRow};
    
  },
  name: "DataTable2",
  props: ["doctype", "doctyp2"],
 

  data() {
    return {
      singleSelect: false,
      selected: this.selected,
      // selected_item: this.selected_item,

      // btnon: true,
      // btnoff: true,
      // isActive: false,
      search: "",
      result_func: this.result_func,

      // min_headers: [
      // { text: "Name ", value: "name" },
      //   { text: "Batch", value: "batch" },
      //   { text: "Client", value: "client" },
      // ],
      headers: this.list_view_filter,
    };
  },
};
</script>

<style>
/* .v-card{
  display: inline;
} */
.v-data-footer__select {
  display: none;
}

.aa {
  background: red !important;
}

.bb {
  background: green !important;
}

.cc {
  background: blue !important;
}

.dd {
  background: yellow !important;
}
.selectrow{
  background-color: greenyellow !important;
}
</style>