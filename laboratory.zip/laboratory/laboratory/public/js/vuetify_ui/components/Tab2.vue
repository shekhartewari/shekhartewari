<template>
  <v-card>
    <v-tabs v-model="tab" background-color="grey" dark>
      <v-tab v-for="item in items" :key="item.tab" background-color="white">
        {{ item.tab }}
      </v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item v-for="item in items" :key="item.tab">
        <!-- <list-simple v-bind:content="filtered(item.content)"></list-simple> -->
        <!-- <list-simple v-bind:content="comp_filter"></list-simple> -->
        <template>
          <v-simple-table dense light height="345px">
            <template v-slot:default>
              <thead>
                <tr>
                  <th class="text-left">Key</th>
                  <th class="text-left">Meta</th>
                  <th class="text-left">Value</th>
                </tr>
              </thead>

              <!-- {{ get_list_comp_prop }} -->
              <!-- <p>{{selected}}</p> -->

              <tbody >
                <!-- <tbody v-for="item in selected" :key="item.name"> -->

                <tr v-for="(value, key) in filtered(item.content)" :key="key">
                  <td>{{ key }}</td>
                  <td>meta</td>
                  <td>{{ value }}</td>
                </tr>
                <tr v-for="(value, key) in meta_list" :key="key">
                  <td>{{ key }}</td>
                  <td>meta</td>
                  <td>{{ value }}</td>
                </tr>
              </tbody>
              <!-- </tbody> -->
            </template>
          </v-simple-table>
        </template></v-tab-item
      ></v-tabs-items
    >
    <div>
      <v-btn ref="" @click="hclick()">click</v-btn>
      <p>{{ selected_item }}</p>
      <!-- <p>{{ get_meta_list}}</p> -->
      <p>{{ p}}</p>

    </div>
  </v-card>
</template>
     
  

<script>
import get_functions from "../composables/labFunctions.js";

export default {
  setup() {
    const { ref } = VueCompositionAPI;
    const { get_meta_list,meta_list, get_meta } = get_functions();
    


    const hclick = function () {
      get_meta(this.doctyp3);
      // for (let i=0; i< get_meta_list.value.length; i++) {
      //   console.log(get_meta_list.value[i].fieldname+":"+get_meta_list.value[i].fieldtype)
        
      // }
      console.log("working")
      // console.log(final.value);
    };
 
    const p = ref(get_meta_list);
    return { get_meta_list,meta_list, get_meta, hclick, p };
  },

  props: {
    selected: {
      type: Object,
    },

    selected_item: {
      type: String,
    },
    // doctype: {
    //   type: String,
    // },
    doctyp3: {
      type: String,
    },
  },
  // components: { ListSimple },
  name: "Tab2",
  data() {
    return {
      tab: null,
      selected: this.selected,
      // doctype:this.doctyp3,

      items: [
        { tab: "General", content: ["name", "client", "nabl"] },
        {
          tab: "Client",
          content: [
            "client",
            "contact",
            "client_order_number",
            "client_reference",
            "client_sample_id",
          ],
        },
        // {
        //   tab: "Environment",
        //   content: [
        //     "priority",
        //     "environmental_conditions",
        //     "internal_use_only",
        //     "attachment",
        //     "remarks",
        //     "container_type",
        //     "sample_no",
        //   ],
        // },

        // {
        //   tab: "Storage",
        //   content: [
        //     "storage_section_column",
        //     "storage_location",
        //     "preservation",
        //     "date_preserved",
        //     "preserver",
        //     "container_title",
        //   ],
        // },
        // {
        //   tab: "Procedure",
        //   content: [
        //     "analysis_specification",
        //     "analysis_profile",
        //     "sample_procedure",
        //     "sampling_deviation",
        //   ],
        // },
        // {
        //   tab: "Meta",
        //   content: ["owner", "modified_by", "modified"],
        // },
      ],
    };
  },
  methods: {
    filtered: function (arr) {
      const filteredByKey = Object.fromEntries(
        Object.entries(this.selected).filter(function ([key, value]) {
          for (let i = 0; i < arr.length; i++) {
            if (key === arr[i]) key;

            return key;
          }
        })
      );
      // console.log("filteredByKey");
      // console.log(filteredByKey);
      return filteredByKey[0];
    },
  },
  computed: {
    comp_filter: function () {
      // let res=this.filtered(["name", "client", "nabl"])
      let res = this.filtered(this.items[0].content);
      // console.log("compted ran");
      // console.log(res);
      return res;
    },
  },
};
</script>
