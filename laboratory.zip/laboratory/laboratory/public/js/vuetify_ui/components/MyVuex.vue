<template>
  <div>
    <ul>
      <li v-for="product in products">
        <span class="name">{{ product.name }}</span>
        <span clas="price">{{ product.price }}</span>
      </li>
      <br />
      <br />
      <li v-for="product in saleProducts">
        <span class="name">{{ product.name }}</span>
        <span clas="price">{{ product.price }}</span>
      </li>
      <button v-on:click="reducePrice(4)">ReducePrice</button>
    </ul>
    <input type="text" yellow />
    <v-btn @click="get_list_func('Sample')">get_list_func()</v-btn>
    <v-btn @click="get_list_exp">get_list_exp</v-btn>
    <v-btn @click="get_list_comp_prop">get_list_comp_prop</v-btn>

    <v-list>
      <v-list-item v-for="n in computed_list" :key="n" link>
        <v-list-item-content>
          <v-list-item-title>{{ n.name }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>

    <v-footer app color="yellow" height="72" inset>
      Sample Client User DocType
      <v-text-field
        v-model="x_comp"
        background-color="red lighten-5"
        dense
        flat
        hide-details
        rounded
        solo
      ></v-text-field>
      <v-text-field
        v-model="in_exp"
        background-color="red lighten-5"
        dense
        flat
        hide-details
        rounded
        solo
      ></v-text-field>
    </v-footer>
  </div>
</template>

<script>
let computed_list = [];
let func_list = [];
let list_at_start = [];

let result_comp = "water";

let result_func = "suger";
export default {
  name: "MyVuex",

  methods: {
    reducePrice: function (amount) {
      this.$store.dispatch("reducePrice", amount);
    },
    // ...mapActions([
    //   'reducePrice'
    // ])
    get_list_func: function (y) {
      frappe.call({
        method: "frappe.client.get_list",
        args: {
          doctype: y,
          filters: [],
        },
        callback: function (r) {
          r = r.message;
          result_func = null;
          console.log(r);
          result_func = r;
          return result_func;
        },
      });
    },
  },

  computed: {
    get_list_comp_prop: function () {
      frappe.call({
        method: "frappe.client.get_list",
        args: {
          doctype: this.x_comp,
          filters: {},
        },
        callback: function (r) {
          computed_list.length = 0;
          result_comp = r.message;
          result_comp.forEach((element) => {
            computed_list.push(element);
          });
          console.log(computed_list);
          return computed_list;
        },
      });
    },
    products() {
      return this.$store.state.products;
    },
    saleProducts() {
      return this.$store.getters.saleProducts;
    },
    // ...mapGetters([
    //   'saleProducts'
    // ])
  },
  data() {
    return {
      drawer: null,

      xd: "Sample",
      x_comp: "Client",
      x_exp: "Quote",
      computed_list: computed_list,
      list_at_start: list_at_start,
    };
  },
};
</script>