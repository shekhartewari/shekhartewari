import VueCompositionAPI from '..//..//..//..//..//..//frappe/node_modules/@vue/composition-api'

Vue.use(VueCompositionAPI)
// console.log(VueCompositionAPI)
// export const ref =  33;