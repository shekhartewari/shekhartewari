<template>
  <v-app id="VuetifyApp">
    <!-- <v-app-bar  app top color="primary" height="20px" >v-app-bar </v-app-bar> -->

    <!-- <v-main style="padding: 0;" class="d-block-ruby"> -->
    <!-- <router-view :key="$route.fullPath"></router-view> -->
    

    <router-view></router-view>
    <!-- <Base></Base> -->
    <!-- <router-link :to="{ name: 'sidebar' }">MAIN </router-link>
    <router-link :to="{ name: 'base' }">BASE</router-link> -->
    <!-- <router-link :to="{name: 'discord'}">DISCORD </router-link> -->
    <!-- <router-link :to="{ name: 'datatable2' }">DATATABLE2 </router-link>
    <router-link :to="{ name: 'tab2' }">TAB2 </router-link>
    <router-link :to="{ name: 'brew' }">BREW </router-link>
    <router-link :to="{ name: 'splitpanes' }">SPLITPANES </router-link> -->
    <!-- <navbar>      </navbar> -->

    <!-- <sidebar-2></sidebar-2> -->
 <!-- <my-form></my-form> -->
 
    
    <!-- <Hello-world></Hello-world> -->
    <!-- <system-bar :username="user.username"></system-bar> -->

    <!-- <Navigation-drawer > </Navigation-drawer> -->
    <!-- <data-table-3></data-table-3> -->
    <!-- <Iframe></Iframe> -->
    <!-- <data-table-2></data-table-2> -->
    <!-- <Employee-list></Employee-list> -->
    <!-- <prop-sizing></prop-sizing> -->
    <!-- <v-bottom-navigation>Bottom Navigation</v-bottom-navigation> -->
    <!-- <Discord class="d-block"></Discord> -->
    <!-- <My-vuex></My-vuex> -->
    <!-- </v-main> -->
  </v-app>
</template>

<script>

// import * as imported from "..//laboratory.js";

// import NavigationDrawer from "./components/NavigationDrawer.vue";
// import PropSizing from "./components/Prop-sizing.vue";
// import Navbar from "./components/Navbar.vue";
// import Iframe from "./components/Iframe.vue";
// import sidebar from"./components/Sidebar.vue";

// import SystemBar from './components/SystemBar.vue'
// import EmployeeList from "./components/EmployeeList.vue";
// import ButtonCounter from "../element_ui/components/ButtonCounter.vue";
// import DataTable3 from "./components/DataTable3.vue";
// import DataTable2 from "./components/DataTable2.vue";
// import BottomNavigation from './components/BottomNavigation.vue'

// import MyVuex from './components/MyVuex.vue';

// import Discord from './examples/wireframes/discord.vue'
// import Base from './examples/wireframes/Base.vue'

// import HelloWorld from './components/HelloWorld.vue'

// import {mapActions} from '../../node_modules/vuex/dist/vuex';
// import {mapGetters} from '../../node_modules/vuex/dist/vuex';
import MyForm from "./components/MyForm.vue"

export default {
  name: "VuetifyApp",
  

  components: {
    // HelloWorld,
    // PropSizing,
    // Discord,
    // SystemBar ,
    // Navbar,
    // NavigationDrawer,
    // BottomNavigation,
    // DataTable3,
    // DataTable2,
    // Iframe,
    // EmployeeList,
    // ButtonCounter,
    // MyVuex,
    // Base,
    // sidebar,
    MyForm
   
    
    
  },

  data() {
    return {
      user: {
        username: frappe.session.user,
      },
    };
  },

  computed: {},

  methods: {},
  beforeCreate() {
    // alert("beforCreate hook has been called");
    // console.log("beforCreate hook has been called");
  },
  created() {
    // alert("Created hook has been called");
    // console.log("Created");
  },
  beforeMount() {
    // alert("beforeMount is called");
    // console.log("beforeMount");
  },
  mounted() {
    // alert("mounted has been called");
    console.log(process.env.NODE_ENV);
    // console.log("Mounted");
  },
  onDestroyClick: function () {
    // this.$destroy();
    console.log("Destroyed");
  },
  activated() {
    // console.log("activated");
  },
  deactivated() {
    // console.log("deactivated");
  },
  beforeDestroy: function () {
    // this.$root.$el.parentNode.removeChild(this.$root.$el)
    // console.log("beforeDestroy");
  },

  afterDestroy: function () {
    // console.log("afterDestroy");
  },
};
</script>
<style>
/* *{
    height:inherit
} */
/* iframe {
  display: flex;
} */

.v-application--wrap {
  display: block;
}
*{ text-transform: none !important; }
</style>