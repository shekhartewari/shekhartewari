// const {ref, reactive, toRefs} = VueCompositionAPI;
export default function () {
    

    const { ref, reactive ,toRefs } = VueCompositionAPI; 
    const val2 = ref("");
    const breweries = reactive({ list2: [] });
    const submitted = async function () {
      const response = await fetch(
        `https://api.openbrewerydb.org/breweries/?by_name=${val2.value}`
      );
      const json = await response.json();
      
      breweries.list2 = json;
      console.log(breweries.list2);
      console.log(val2)
      console.log(breweries)
     
    };
    // console.log(list2)
    

    return { val2, ...toRefs(breweries), submitted };
}