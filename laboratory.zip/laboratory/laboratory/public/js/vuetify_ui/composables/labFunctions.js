
const get_functions = function () {

    
    const { ref, reactive, toRefs } = VueCompositionAPI;
    const result_func = [];
    const get_meta_list = ref(["apple"]);
    const meta_list=ref([]);
    const list_view_filter = ref([]);
    const test_func_result = [];
    const selected_item = "";
    const selected = [];
    const doctype="";
  
  

    function get_list_func(doctype) {
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: doctype,
                filters: [],
                limit_page_length: 2100,
                fields: ["*"],
            },
            callback: function (r) {
                r = r.message;
                result_func.length = 0;

                r.forEach((element) => {
                    result_func.push(element);
                });
                // console.log("result_func")
                console.log(result_func);
                return result_func;
            },
        });
    };
    function get_meta (doctype) {
        frappe.call({
            method:
                "laboratory.laboratory.page.vuetify_page.vuetify_page.get_meta_wl",
            args: {
                doctype: doctype,
            },
            callback: function (r) {
                r = r.message;
            
                get_meta_list.value.length = 0;

                r.forEach((element) => {
                    get_meta_list.value.push(element);
                });
                console.log(get_meta_list.value);
                meta_list.value.length=0;
                for (let i=0; i< get_meta_list.value.length; i++) {
                    meta_list.value.push(get_meta_list.value[i].fieldname,get_meta_list.value[i].fieldtype)
                    
                  }
                  console.log(meta_list.value)
                return meta_list.value ,get_meta_list.value;
            },
        });
    };
    const emit_selected = function (r) {
        this.$emit("emit_selected", r);
    };
    const emit_selected_item = function (r) {
        this.$emit("emit_selected_item", r);
    };
    const get_report_list = function (doctype, report_name) {
        frappe.call({
            method: "laboratory.laboratory.lab_api.lab_api.get_report_list",
            args: {
                doctype: doctype,
                report_name: report_name,
            },

            callback: function (r) {
                // r = r.message;
                // const get_meta_list = [];
                // get_meta_list.length = 0;

                // r.forEach((element) => {
                //   get_meta_list.push(element);
                // });
                console.log(r.message);
                console.log(JSON.stringify(r.message));
                test_func_result.length = 0;
                test_func_result.push(JSON.stringify(r.message));

                return test_func_result;
            },
        });
    };
    const get_form_load = function () {
        let myHeaders = new Headers();
        myHeaders.append(
            "Authorization",
            "token 54f1ce52593a12a:260fabed6ffb890"
        );
        // myHeaders.append(
        //   "Cookie",
        //   "sid=Guest; system_user=no; full_name=Guest; user_id=Guest; user_image="
        // );
        const params = {
            doctype: "Report",
            name: "Sample",
        };
        let requestOptions = {
            method: "GET",
            // headers: myHeaders,
            redirect: "follow",
        };

        let url =
            "http://labone:8000/api/method/frappe.desk.form.load.getdoc" +
            "?" +
            "doctype" +
            "=" +
            params.doctype +
            "&" +
            "name" +
            "=" +
            params.name;

        let r = fetch(url, requestOptions)
            .then((response) => response.json())
            // .then((result) => (result = result.json))
            .then((result) => console.log(result))

            .catch((error) => console.log("error", error));
    };
    const get_report_view = function (doctype, view) {

        const params = {
            doctype: doctype,
            // fields: ["`tabSample`.`workflow_state`","`tabSample`.`name`","`tabSample`.`docstatus`"],

            fields: JSON.parse(test_func_result),
            filters: [],
            order_by: "`tabSample`.`modified`+desc",
            start: 0,
            page_lnegth: 10,
            view: view,
            with_comment_count: true,

        };
        frappe.call({
            method: "frappe.desk.reportview.get",
            args: {
                doctype: params.doctype,
                fields: JSON.stringify(params.fields),
            },
            callback: function (r) {
                if (!r.exc) {
                    console.log(r.message);
                    console.log(JSON.stringify(r.message.values));
                }
                return r.values;
            },
            error: (r) => {
                console.log("error ocurred")
            }
        });
    };
    const get_report_view2 = function () {
        // this.$refs.report_list.click()
        let myHeaders = new Headers();
        // myHeaders.append(
        //   "Authorization",
        //   "token 54f1ce52593a12a:260fabed6ffb890"
        // );
        // myHeaders.append(
        //   "Cookie",
        //   "sid=Guest; system_user=no; full_name=Guest; user_id=Guest; user_image="
        // );
        const params = {
            doctype: "Sample",
            // fields: ["`tabSample`.`workflow_state`","`tabSample`.`name`","`tabSample`.`docstatus`"],

            fields: JSON.parse(test_func_result),
            filters: [],
            order_by: "`tabSample`.`modified`+desc",
            start: 0,
            page_lnegth: 10,
            view: "Report",
            with_comment_count: true,
        };
        let requestOptions = {
            method: "GET",
            // headers: myHeaders,
            redirect: "follow",
        };

        let url =
            window.location.origin +
            "/api/method/frappe.desk.reportview.get" +
            "?" +
            "doctype" +
            "=" +
            params.doctype +
            "&" +
            "fields" +
            "=" +
            JSON.stringify(params.fields);

        let r = fetch(url, requestOptions)
            .then((response) => response.json())
            .then((result) => (result = result))
            .then((result) => console.log(result))
            .catch((error) => console.log("error", error));
    };
    function get_list_view(doctype) {
        get_meta(doctype);
        frappe.call({
            method:
                // not working
                "frappe.desk.doctype.list_view_settings.list_view_settings.get_default_listview_fields",
            args: {
                doctype: doctype,
            },
            callback: function (r) {
                r = r.message;
                r.push("name");
                console.log(r);

                list_view_filter.value.length = 0;

                r.forEach((element) => {
                    for (let i = 0; i < get_meta_list.value.length; i++) {
                        if (get_meta_list.value[i].fieldname === element) {
                            list_view_filter.value.push({
                                text: get_meta_list.value[i].label,
                                value: get_meta_list.value[i].fieldname,
                            });
                        }
                    }
                });
                list_view_filter.value.unshift({ text: "Name ", value: "name" });
                console.log(list_view_filter.value);
                return list_view_filter.value;
            },
        });
    };
    const btnswitch = function (id) {
        let btnselector = document.getElementById(id);
        if (btnselector.style.backgroundColor === "orange") {
            btnselector.style.backgroundColor = "lightgrey";
            console.log(id + "grey");
            // btnselector.disabled =true;
            // this.btnon = true;
        } else {
            btnselector.style.backgroundColor = "orange";
            // this.btnon = false;
            // btnselector.disabled = false;
            console.log(id + "orange");
        }
    };
    const dblclickRow = function (item, e) {

        try {
            (document.getElementsByClassName("selectrow")).forEach(element => {
                element.classList.remove("selectrow")
                // console.log(e.target.firstChild.data)
            });
        }
        catch (err) {
            // console.log("Null")
        }
        finally {
            e.target.parentElement.classList.add("selectrow");
            this.selected_item = document.getElementsByClassName("selectrow")[0].cells[1].textContent
            // console.log(e.target.firstChild.data)  
            // console.log(this.selected_item)
        };
    };
    // function to make list from object filtered by key
    const filtered = function (arr, obj) {
        const filteredByKey = Object.fromEntries(
            Object.entries(obj).filter(function ([key, value]) {
                for (let i = 0; i < arr.length; i++) {
                    if (key === arr[i]) return key;
                }
            })
        );


        return filteredByKey;
    };


    return { result_func, meta_list,get_meta_list, list_view_filter, test_func_result, selected, selected_item, get_list_func, get_meta, emit_selected, emit_selected_item, get_report_list, get_form_load, get_report_view, get_report_view2, get_list_view, btnswitch, dblclickRow }
}
export default
    get_functions





