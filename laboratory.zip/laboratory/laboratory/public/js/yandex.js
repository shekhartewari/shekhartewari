console.log("uploading yandex.js");

document.addEventListener("DOMContentLoaded", (event)=>{
    let navbar = document.querySelector(".navbar-collapse");
    let anc = document.createElement('a');
    anc.id="ytWidget";
    anc.innerText = "welcome to shekhar google";
    navbar.prepend(anc);

    let srctag = document.createElement('script');
    srctag.src = "https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=light&autoMode=true" 
    srctag.type="text/javascript";
    document.head.appendChild(srctag);

})

document.querySelector(".navbar-collapse")