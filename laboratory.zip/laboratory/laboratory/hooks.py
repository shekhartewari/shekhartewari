# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from . import __version__ as app_version

app_name = "laboratory"
app_title = "Laboratory"
app_publisher = "Shekhar"
app_description = "Lab Testing "
app_icon = "octicon octicon-file-directory"
app_color = "grey"
app_email = "shekharetwari@gmail.com"
app_license = "PERSONAL"

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/laboratory/css/laboratory.css"
app_include_css = ["/assets/laboratory/shekhar/css/desk.css",
                    "/assets/laboratory/node_modules/element-ui/lib/theme-chalk/index.css",

                    # Add Element-ui
                    "https://unpkg.com/element-ui/lib/theme-chalk/index.css",

                    # Add Vuetify
                    "https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900",
                    "https://cdn.jsdelivr.net/npm/@mdi/font@4.x/css/materialdesignicons.min.css",
                    "https://cdn.jsdelivr.net/npm/vuetify@2.5.3/dist/vuetify.min.css"
                    # "https://unpkg.com/mathlive@0.27.4/dist/mathlive.css",
                    # "https://unpkg.com/mathlive@0.27.4/dist/mathlive.core.css",


                     # Add splitpanes
                    # "https://unpkg.com/splitpanes/dist/splitpanes.css"

                    ]

# app_include_js = "/assets/laboratory/js/shekhar_sidenav.js"
# app_include_js = "/assets/laboratory/js/yandex.js"
app_include_js = [  
                    # "https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js",
                    # "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js", 
                    # "https://code.jquery.com/ui/1.12.1/jquery-ui.min.js",
                    "/assets/js/laboratory.min.js",
                    # "/assets/laboratory/js/laboratory.js",
                    # "/assets/laboratory/js/element_ui/element_ui.js",

                    # Add Element-Ui
                    "/assets/laboratory/node_modules/element-ui/lib/index.js",
	                "/assets/laboratory/node_modules/element-ui/lib/umd/locale/en.js",
                    # "https://unpkg.com/element-ui/lib/index.js",
                    # "https://unpkg.com/element-ui/lib/umd/locale/en.js",
                    # Add Axios
                    # "https://unpkg.com/axios/dist/axios.js",
                    # "https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.js",
                    # Add Vue 3
                    # "https://unpkg.com/vue@next",

                    


                    # Add Vuetify
                    # "/assets/laboratory/node_modules/vuetify/lib/index.js",
                    # "/assets/laboratory/node_modules/vuetify/lib/locale/en.js"
                    # "https://cdn.jsdelivr.net/npm/vue@2.6",
                    # "https://cdn.jsdelivr.net/npm/vue-smooth-dnd@0.8.1/dist/vue-smooth-dnd.min.js",
                    
                    "https://cdn.jsdelivr.net/npm/vuetify@2.5.3/dist/vuetify.js",

                    # Add splitpanes
                    # "https://unpkg.com/splitpanes",
                    
                    "https://cdn.jsdelivr.net/npm/@vue/composition-api@1.0.3",


                    # "/assets/laboratory/js/element_ui/components/file1.js",
                    # "/assets/laboratory/js/element_ui/element_ui.js",
                    # "/assets/laboratory/js/vuetify_ui/vuetify_ui.js",
                    # "/public/js/vuetify_ui/vuetify_ui.js"
                    ]

# include js, css files in header of web template
# web_include_css = "/assets/laboratory/css/laboratory.css"
# web_include_js = "/assets/laboratory/js/laboratory.js"
web_include_js = [
    
  
# "https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js",
# "https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.js",
]

# include js in page
# page_js = {"page" : "public/js/file.js"}
# page_js = {"vuetify_page" : 
#              "https://cdn.jsdelivr.net/npm/@vue/composition-api@1.0.0-rc.11"
# }
# page_js = {"firstpage" : [
#     "public/srtdash/assets/js/page9.js", 
#     "public/srtdash/assets/js/pie-chart.js",
#     "public/srtdash/assets/js/owl-carousel.min.js",
#     "public/srtdash/assets/js/scripts.js",
#     "public/srtdash/assets/js/vendor/jquery-2.2.4.min.js" ,
    
#     # "public/srtdash/assets/js/popper.min.js",
#     # "public/srtdash/assets/js/metisMenu.min.js",
#     # "public/srtdash/assets/js/line-chart.js",
#     # "public/srtdash/assets/js/jquery.slimscroll.min.js",
#     # "public/srtdash/assets/js/jquery.slicknav.min.js",
#     # "public/srtdash/assets/js/bootstrap.min.js",
#     "public/srtdash/assets/js/bar-chart.js",
    
#     "public/srtdash/assets/js/vendor/modernizr-2.8.3.min.js"
# ]
# }
    
   

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
#	"Role": "home_page"
# }

# Website user home page (by function)
# get_website_user_home_page = "laboratory.utils.get_home_page"

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]
# website_generators = ["Sample","Storage Location"]

# Installation
# ------------

# before_install = "laboratory.install.before_install"
# after_install = "laboratory.install.after_install"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "laboratory.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
#	}
# }

# Scheduled Tasks
# ---------------

# scheduler_events = {
# 	"all": [
# 		"laboratory.tasks.all"
# 	],
# 	"daily": [
# 		"laboratory.tasks.daily"
# 	],
# 	"hourly": [
# 		"laboratory.tasks.hourly"
# 	],
# 	"weekly": [
# 		"laboratory.tasks.weekly"
# 	]
# 	"monthly": [
# 		"laboratory.tasks.monthly"
# 	]
# }

# Testing
# -------

# before_tests = "laboratory.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "laboratory.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "laboratory.task.get_dashboard_data"


# }


